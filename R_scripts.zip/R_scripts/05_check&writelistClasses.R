#Set directory where static_ attrites are stored
dir.CAMELS.CH <- 'S:/CAMELS-CH/CAMELS-CH/camels_ch/static_attributes'

#Write out data as .csv
attr.all <- read.table(paste(dir.CAMELS.CH,'selected219_secondary_attributes.csv',sep='/'),
                       sep=';', header=TRUE,stringsAsFactor=FALSE)

hist.Qreg <- hist(attr.all$Abflreg, breaks = seq(1, 16, by = 1), right=FALSE)
hist.Qreg$breaks
hist.Qreg$counts
hist.Qreg$intensities
hist.Qreg$density


gtools::mixedsort(unique(attr.all$Abflreg_nm))
attr.all$gauge_id[which(attr.all$Abflreg==16)]
#merge Abflreg 16 with Abflreg 15, in order to have at least 5 subcatchments per Qregime class
attr.all$Abflreg_nm[which(attr.all$Abflreg==16)] <- "15 pluvio-nival meridional"
attr.all$Abflreg[which(attr.all$Abflreg==16)] <- 15

attr.all$Abflreg_nm[which(attr.all$Abflreg==15)]

#merge Abflreg 2 with Abflreg 1, in order to have at least 5 subcatchments per Qregime class
attr.all$Abflreg_nm[which(attr.all$Abflreg==1)] <- "02 b-glaciaire"
attr.all$Abflreg[which(attr.all$Abflreg==1)] <- 2

write.table(attr.all$Abflreg_nm, 'S:/tina/AML/P3/RR-Former/data/219classes_list.txt',
            quote=FALSE, row.names = FALSE, col.names = FALSE)