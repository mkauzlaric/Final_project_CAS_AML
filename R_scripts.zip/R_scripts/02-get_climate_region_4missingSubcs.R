###########################################
#####     Define climate region       #####
##### extracting it from digitilized #####
#####  Klimaregionen by Begert2007    #####
##########################################

# Load libraries
library(sf)
library(rio)
library(data.table)

# Load workspace generated for the regionalization?
#load("J:/EXAR-CH/Regionalisation/workspace_RegionalisationHBV_corr2.RData")

#Get list with CAMELS CH catchments
basins <- read.table('S:/tina/AML/P3/RR-Former/data/219basins_list.txt')
basins <- basins$V1

#Get catchment inventory (from EXCH project)
#catchs.inv <- as.data.frame(import_list('P:/Hydrologie/EXAR-CH/EXCH_datasets-main/inventory+metadata_dischargedata_stations/Inventar_hydrologische_Daten_EXCH.xlsx',
#                                        which = "ALL", rbind = FALSE),stringsAsFactors=FALSE)
#colnames(catchs.inv) <- gsub('ALL.','',colnames(catchs.inv))
#catchs.inv[,'ID12'] <- sapply(catchs.inv[,'ID12'],as.character)

#Set directory where static_ attrites are stored
dir.CAMELS.CH <- 'S:/CAMELS-CH/CAMELS-CH/camels_ch/static_attributes'

#Get IDs' reference generated within CAMELS-CH
ID.gauges <- readRDS('S:/CAMELS-CH/CAMELS-CH/IDgauges.rds')

#Select gauges retained (removing lakes)
ID.gauges.sel <- ID.gauges[match(basins,ID.gauges$ID),]

#Get attributes extracted for subcatchments in EXCH
attr.all <- readRDS('S:/tina/AML/P3/attrALL.rds')

#check all gauges are in the attribute inventory
ID.gauges.sel$ID12_MK %in% attr.all$ID12

ID.gauges.sel$ID[which(!(ID.gauges.sel$ID12_MK %in% attr.all$ID12))]

missing.ID12 <- ID.gauges.sel$ID12_MK[which(!(ID.gauges.sel$ID12_MK %in% attr.all$ID12))]

ID.gauges.sel[match(missing.ID12,ID.gauges.sel$ID12_MK),c('gauging_st','water_body','country')]

missing.gauge.id <- ID.gauges.sel$ID[which(!(ID.gauges.sel$ID12_MK %in% attr.all$ID12))]
#ID.gauges.sel$ID12_MK %in% attr.all$ID12

# Get shapefile with digitilzed climate regions by Begert,2007  
ClimReg <- st_read('D:/GIS/BA_Silas/klimaregext.shp')

# Get shapefile of CAMELS CH catchments
catchs.CAMELS.CH <- st_read('S:/CAMELS-CH/CAMELS-CH/camels_ch/catchment_delineations/CAMELS_CH_catchments_mod_geomfix.shp')

# Make intersection and get climate region for the missing catchments
# according to majority criterium (maximum overlapping area defines the climate region assigned)
ClimReg.int <- st_intersection(st_transform(ClimReg,st_crs(catchs.CAMELS.CH)),
                               catchs.CAMELS.CH)

#Prealloation attribute table
attr <- as.data.frame(matrix(0,length(missing.gauge.id),3),
                      stringsAsFactors=FALSE)
colnames(attr) <- c("gauge_id","Klimaregio","Klimaregio_all")
attr$gauge_id <- missing.gauge.id

for (catch.i in 1:length(missing.gauge.id)) {
  
  catch.sel <- catchs.CAMELS.CH[which(catchs.CAMELS.CH$gauge_id==missing.gauge.id[catch.i]),]
  
  print(paste0("#",catch.i,": ",catch.sel$gauge_id," ",
               catch.sel$water_body,"-",catch.sel$gauge_name))
  
  area.frac <- as.numeric(st_area(ClimReg.int[which(ClimReg.int$gauge_id==missing.gauge.id[catch.i]),]))/
    st_drop_geometry(ClimReg.int[which(ClimReg.int$gauge_id==missing.gauge.id[catch.i]),"Shape_Area"])
  
  attr$Klimaregio[catch.i] <- st_drop_geometry(ClimReg.int[which(ClimReg.int$gauge_id==attr$gauge_id[catch.i]),"klimareg"])[which.max(area.frac$Shape_Area),"klimareg"]
  
  # What is the climate region covering most of the catchment area?
  print(paste0("Klimaregio"," ",attr$Klimaregio[catch.i]))
  
  attr$Klimaregio_all[catch.i] <- unlist(lapply(st_drop_geometry(ClimReg.int[which(ClimReg.int$gauge_id==attr$gauge_id[catch.i]),"klimareg"]),
                                                paste, collapse=","))
  
  #Retain what are all climate regions present within the catchment
  print(paste0("Klimaregio_all"," ",attr$Klimaregio_all[catch.i]))
  
  rm(area.frac)
  
}

saveRDS(attr, 'S:/tina/AML/P3/attr_missing2.rds')
