########################################
#####       Merge attributes       #####
#####  Climate Region and Qregime  #####
#####      for all catchments      #####
########################################

library(dplyr)

#Read attributes extracted in the previous steps
attr <- readRDS('S:/tina/AML/P3/attr_missing2.rds')
#select columns to be retained
attr <- attr %>% select(c(gauge_id,Klimaregio,Abflreg,Abflreg_nm))

#Get attributes extracted for subcatchments in EXCH
attr.all <- readRDS('S:/tina/AML/P3/attrALL.rds')

#Add streamflow regime names
AbflReg.lookuptable <- setNames(cbind.data.frame(seq(1,18,1),
                                                 c("01 a-glaciaire","02 b-glaciaire","03 a-glacio-nival",
                                                   "04 b-glacio-nival","05 nivo-glaciaire","06 nival alpin",
                                                   "07 nival de transition","08 nivo-pluvial prealpin","09 pluvial superieur",
                                                   "10 pluvial inferieur","11 pluvial jurassien","12 nivo-pluvial jurassien",
                                                   "13 nival meridional","14 nivo-pluvial meridional","15 pluvio-nival meridional",
                                                   "16 pluvial meridional","17 glaciaire meridional","18 glacio-nival meridional"),
                                                 stringsAsFactors=FALSE),
                                c('AbflReg.Nr','AbflReg.Type'))

attr.all <- attr.all %>% mutate(Abflreg_nm=rep(" ",nrow(attr.all)), .after=Abflreg)

attr.all$Abflreg_nm <- AbflReg.lookuptable[match(attr.all$Abflreg,AbflReg.lookuptable$AbflReg.Nr),'AbflReg.Type']

#select columns to be retained
attr.all <- attr.all %>% select(c(ID12,Klimaregio,Abflreg,Abflreg_nm))

# Get list of basins to be used with RR-Former
basins <- read.table('S:/tina/AML/P3/RR-Former/data/219basins_list.txt')
basins <- basins$V1

#Get IDs' reference generated within CAMELS-CH
ID.gauges <- readRDS('S:/CAMELS-CH/CAMELS-CH/IDgauges.rds')

#Select gauges
ID.gauges.sel <- ID.gauges[match(attr$gauge_id,ID.gauges$ID),]
missing.ID12 <- ID.gauges.sel$ID12_MK[which(!(ID.gauges.sel$ID12_MK %in% attr.all$ID12))]
missing.gauge.id <- ID.gauges.sel$ID[which(!(ID.gauges.sel$ID12_MK %in% attr.all$ID12))]
#Make dictionary basins' gauge_id - basins' ID12
basins.ID12 <- ID.gauges$ID12_MK[match(basins,ID.gauges$ID)]

#Prepare dataframe with all secondary attributes
#for possible stratified kfold validation in RR-Former
attr.all <- attr.all[match(basins.ID12,attr.all$ID12),]
attr.all <- attr.all %>% mutate(gauge_id=basins,.after=ID12)
attr.all <- attr.all[,-1]
attr.all[match(attr$gauge_id,attr.all$gauge_id),] <- attr

#Set directory where static_ attrites are stored
dir.CAMELS.CH <- 'S:/CAMELS-CH/CAMELS-CH/camels_ch/static_attributes'

#Write out data as .csv
write.table(attr.all,
            paste(dir.CAMELS.CH,'selected219_secondary_attributes.csv',sep='/'),
            sep=';', row.names = FALSE, col.names = TRUE, quote=FALSE)

