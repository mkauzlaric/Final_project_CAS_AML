## Harvest results

# For training of transformer with CAMELS CH

# Get run name
list.dirs('S:/tina/AML/P3/RR-Former/runs',recursive=FALSE, full.names = FALSE)

# Get training results
tranformer.wstatatt.CAMELS.CH <- read.table(paste(list.dirs('S:/tina/AML/P3/RR-Former/runs',
                                                    recursive=FALSE)[2],'log_train.csv', sep='/'),
                                            skip=1, header=TRUE, sep=',', stringsAsFactors=FALSE)

# Get training results
tranformer.CAMELS.CH <- read.table(paste(list.dirs('S:/tina/AML/P3/RR-Former/runs',
                                                   recursive=FALSE)[2],'log_train.csv', sep='/'),
                                   skip=1, header=TRUE, sep=',', stringsAsFactors=FALSE)



plot(tranformer.CAMELS.CH$epoch,
     tranformer.CAMELS.CH$train_mse,
     type='l', col='firebrick2',
     xlab="epoch", ylab="NSE or MSE [-]",
     ylim=c(-1,1))
title("CAMELS-CH")
lines(c(-100,100),c(0,0),col='black',lty=2)
lines(tranformer.CAMELS.CH$epoch,
     tranformer.CAMELS.CH$train_nse,
     col='blue3')
lines(tranformer.CAMELS.CH$epoch,
      tranformer.CAMELS.CH$val_mse,
      col='lightsalmon')
lines(tranformer.CAMELS.CH$epoch,
      tranformer.CAMELS.CH$val_nse,
      col='cadetblue1')
lines(tranformer.wstatatt.CAMELS.CH$epoch,
      tranformer.wstatatt.CAMELS.CH$train_mse,
      col='goldenrod3')
lines(tranformer.wstatatt.CAMELS.CH$epoch,
      tranformer.wstatatt.CAMELS.CH$train_nse,
      col='olivedrab')
lines(tranformer.wstatatt.CAMELS.CH$epoch,
      tranformer.wstatatt.CAMELS.CH$val_mse,
      col='goldenrod1')
lines(tranformer.wstatatt.CAMELS.CH$epoch,
      tranformer.wstatatt.CAMELS.CH$val_nse,
      col='olivedrab3')
legend("bottomright", 
       legend = c("Tr MSE", "Tr NSE", "Val MSE", "Val NSE",
                  "Tr MSE w.statatt", "Tr NSE w.statatt", "Val MSE w.statatt", "Val NSE w.statatt"), 
       col = c("firebrick2", "blue3", "lightsalmon", "cadetblue1",
               "goldenrod3", "olivedrab", "goldenrod1", "olivedrab3"), 
       lty = 1,  lwd = 2, box.lwd = 0, box.lty = 0,
       title = "Performance")


list.dirs('S:/tina/AML/RR-Former/runs',recursive=FALSE, full.names = FALSE)

# Get training results
tranformer.wstatatt.CAMELS.US <- read.table(paste(list.dirs('S:/tina/AML/RR-Former/runs',
                                                   recursive=FALSE)[1],'log_train.csv', sep='/'),
                                   skip=1, header=TRUE, sep=',', stringsAsFactors=FALSE)

tranformer.CAMELS.US <- read.table(paste(list.dirs('S:/tina/AML/RR-Former/runs',
                                                   recursive=FALSE)[2],'log_train.csv', sep='/'),
                                   skip=1, header=TRUE, sep=',', stringsAsFactors=FALSE)


plot(tranformer.CAMELS.US$epoch,
     tranformer.CAMELS.US$train_mse,
     type='l', col='firebrick2',
     xlab="epoch", ylab="NSE or MSE [-]",
     ylim=c(-1,1))
title("CAMELS-US")
lines(c(-100,100),c(0,0),col='black',lty=2)
lines(tranformer.CAMELS.US$epoch,
      tranformer.CAMELS.US$train_nse,
      col='blue3')
lines(tranformer.CAMELS.US$epoch,
      tranformer.CAMELS.US$val_mse,
      col='lightsalmon')
lines(tranformer.CAMELS.US$epoch,
      tranformer.CAMELS.US$val_nse,
      col='cadetblue1')
lines(tranformer.wstatatt.CAMELS.US$epoch,
      tranformer.wstatatt.CAMELS.US$train_mse,
      col='goldenrod3')
lines(tranformer.wstatatt.CAMELS.US$epoch,
      tranformer.wstatatt.CAMELS.US$train_nse,
      col='olivedrab')
lines(tranformer.wstatatt.CAMELS.US$epoch,
      tranformer.wstatatt.CAMELS.US$val_mse,
      col='goldenrod1')
lines(tranformer.wstatatt.CAMELS.US$epoch,
      tranformer.wstatatt.CAMELS.US$val_nse,
      col='olivedrab3')
legend("bottomright", 
       legend = c("Tr MSE", "Tr NSE", "Val MSE", "Val NSE",
                  "Tr MSE w.statatt", "Tr NSE w.statatt", "Val MSE w.statatt", "Val NSE w.statatt"), 
       col = c("firebrick2", "blue3", "lightsalmon", "cadetblue1",
               "goldenrod3", "olivedrab", "goldenrod1", "olivedrab3"), 
       lty = 1,  lwd = 2, box.lwd = 0, box.lty = 0,
       title = "Performance")


# Get training results
LSTM.CAMELS.US <- read.table(paste(list.dirs('S:/tina/AML/RR-Former_Colab/runs',
                                                   recursive=FALSE),'log_train.csv', sep='/'),
                                   skip=1, header=TRUE, sep=',', stringsAsFactors=FALSE)


plot(tranformer.CAMELS.US$epoch,
     tranformer.CAMELS.US$train_mse,
     type='l', col='firebrick2',
     xlab="epoch", ylab="NSE or MSE [-]",
     ylim=c(-1,1))
title("CAMELS-US")
lines(c(-100,100),c(0,0),col='black',lty=2)
lines(tranformer.CAMELS.US$epoch,
      tranformer.CAMELS.US$train_nse,
      col='blue3')
lines(tranformer.CAMELS.US$epoch,
      tranformer.CAMELS.US$val_mse,
      col='lightsalmon')
lines(tranformer.CAMELS.US$epoch,
      tranformer.CAMELS.US$val_nse,
      col='cadetblue1')
lines(tranformer.wstatatt.CAMELS.US$epoch,
      tranformer.wstatatt.CAMELS.US$train_mse,
      col='goldenrod3')
lines(tranformer.wstatatt.CAMELS.US$epoch,
      tranformer.wstatatt.CAMELS.US$train_nse,
      col='olivedrab')
lines(tranformer.wstatatt.CAMELS.US$epoch,
      tranformer.wstatatt.CAMELS.US$val_mse,
      col='goldenrod1')
lines(tranformer.wstatatt.CAMELS.US$epoch,
      tranformer.wstatatt.CAMELS.US$val_nse,
      col='olivedrab3')
lines(LSTM.CAMELS.US$epoch,
      LSTM.CAMELS.US$train_mse,
      col='ivory4')
lines(LSTM.CAMELS.US$epoch,
      LSTM.CAMELS.US$train_nse,
      col='darkmagenta')
lines(LSTM.CAMELS.US$epoch,
      LSTM.CAMELS.US$val_mse,
      col='ivory3')
lines(LSTM.CAMELS.US$epoch,
      LSTM.CAMELS.US$val_nse,
      col='darkorchid1')
legend("bottomright", 
       legend = c("Tr MSE", "Tr NSE", "Val MSE", "Val NSE",
                  "Tr MSE w.statatt", "Tr NSE w.statatt", "Val MSE w.statatt", "Val NSE w.statatt",
                  "Tr MSE LSTM", "Tr NSE LSTM", "Val MSE LSTM", "Val NSE LSTM"), 
       col = c("firebrick2", "blue3", "lightsalmon", "cadetblue1",
               "goldenrod3", "olivedrab", "goldenrod1", "olivedrab3",
               "ivory4", "darkmagenta", "ivory3", "darkorchid1"), 
       lty = 1,  lwd = 2, box.lwd = 0, box.lty = 0,
       title = "Performance")




# Get training results
tranformer.CAMELS.CH <- read.table(paste(list.dirs('S:/tina/AML/P3/RR-Former/runs',
                                                   recursive=FALSE)[2],'log_train.csv', sep='/'),
                                   skip=1, header=TRUE, sep=',', stringsAsFactors=FALSE)

# Get training results
LSTM.CAMELS.CH <- read.table(paste(list.dirs('S:/tina/AML/P3/RR-Former/runs',
                                             recursive=FALSE)[1],'log_train.csv', sep='/'),
                             skip=1, header=TRUE, sep=',', stringsAsFactors=FALSE)


plot(tranformer.CAMELS.CH$epoch,
     tranformer.CAMELS.CH$train_mse,
     type='l', col='firebrick2',
     xlab="epoch", ylab="NSE or MSE [-]",
     ylim=c(-1,1))
title("CAMELS-CH")
lines(c(-100,100),c(0,0),col='black',lty=2)
lines(tranformer.CAMELS.CH$epoch,
      tranformer.CAMELS.CH$train_nse,
      col='blue3')
lines(tranformer.CAMELS.CH$epoch,
      tranformer.CAMELS.CH$val_mse,
      col='lightsalmon')
lines(tranformer.CAMELS.CH$epoch,
      tranformer.CAMELS.CH$val_nse,
      col='cadetblue1')
#lines(tranformer.wstatatt.CAMELS.CH$epoch,
#      tranformer.wstatatt.CAMELS.CH$train_mse,
#      col='goldenrod3')
#lines(tranformer.wstatatt.CAMELS.CH$epoch,
#      tranformer.wstatatt.CAMELS.CH$train_nse,
#      col='olivedrab')
#lines(tranformer.wstatatt.CAMELS.CH$epoch,
#      tranformer.wstatatt.CAMELS.CH$val_mse,
#      col='goldenrod1')
#lines(tranformer.wstatatt.CAMELS.CH$epoch,
#      tranformer.wstatatt.CAMELS.CH$val_nse,
#      col='olivedrab3')
lines(LSTM.CAMELS.CH$epoch,
      LSTM.CAMELS.CH$train_mse,
      col='ivory4')
lines(LSTM.CAMELS.CH$epoch,
      LSTM.CAMELS.CH$train_nse,
      col='darkmagenta')
lines(LSTM.CAMELS.CH$epoch,
      LSTM.CAMELS.CH$val_mse,
      col='ivory3')
lines(LSTM.CAMELS.CH$epoch,
      LSTM.CAMELS.CH$val_nse,
      col='darkorchid1')
#legend("bottomright", 
#       legend = c("Tr MSE", "Tr NSE", "Val MSE", "Val NSE",
#                  "Tr MSE w.statatt", "Tr NSE w.statatt", "Val MSE w.statatt", "Val NSE w.statatt",
#                  "Tr MSE LSTM", "Tr NSE LSTM", "Val MSE LSTM", "Val NSE LSTM"), 
#       col = c("firebrick2", "blue3", "lightsalmon", "cadetblue1",
#               "goldenrod3", "olivedrab", "goldenrod1", "olivedrab3",
#               "ivory4", "darkmagenta", "ivory3", "darkorchid1"), 
#       lty = 1,  lwd = 2, box.lwd = 0, box.lty = 0,
#       title = "Performance")
legend("bottomright", 
       legend = c("Tr MSE", "Tr NSE", "Val MSE", "Val NSE",
                  "Tr MSE LSTM", "Tr NSE LSTM", "Val MSE LSTM", "Val NSE LSTM"), 
       col = c("firebrick2", "blue3", "lightsalmon", "cadetblue1",
               "ivory4", "darkmagenta", "ivory3", "darkorchid1"), 
       lty = 1,  lwd = 2, box.lwd = 0, box.lty = 0,
       title = "Performance")



# Get training results
tranformer.CAMELS.US <- read.table(paste(list.dirs('S:/tina/AML/RR-Former/runs',
                                                   recursive=FALSE)[2],'log_train.csv', sep='/'),
                                   skip=1, header=TRUE, sep=',', stringsAsFactors=FALSE)

# Get training results
LSTM.CAMELS.US <- read.table(paste(list.dirs('S:/tina/AML/RR-Former/runs',
                                             recursive=FALSE)[1],'log_train.csv', sep='/'),
                             skip=1, header=TRUE, sep=',', stringsAsFactors=FALSE)


plot(tranformer.CAMELS.US$epoch,
     tranformer.CAMELS.US$train_mse,
     type='l', col='firebrick2',
     xlab="epoch", ylab="NSE or MSE [-]",
     ylim=c(-1,1))
title("CAMELS-USA")
lines(c(-100,100),c(0,0),col='black',lty=2)
lines(tranformer.CAMELS.US$epoch,
      tranformer.CAMELS.US$train_nse,
      col='blue3')
lines(tranformer.CAMELS.US$epoch,
      tranformer.CAMELS.US$val_mse,
      col='lightsalmon')
lines(tranformer.CAMELS.US$epoch,
      tranformer.CAMELS.US$val_nse,
      col='cadetblue1')
#lines(tranformer.wstatatt.CAMELS.US$epoch,
#      tranformer.wstatatt.CAMELS.US$train_mse,
#      col='goldenrod3')
#lines(tranformer.wstatatt.CAMELS.US$epoch,
#      tranformer.wstatatt.CAMELS.US$train_nse,
#      col='olivedrab')
#lines(tranformer.wstatatt.CAMELS.US$epoch,
#      tranformer.wstatatt.CAMELS.US$val_mse,
#      col='goldenrod1')
#lines(tranformer.wstatatt.CAMELS.US$epoch,
#      tranformer.wstatatt.CAMELS.US$val_nse,
#      col='olivedrab3')
lines(LSTM.CAMELS.US$epoch,
      LSTM.CAMELS.US$train_mse,
      col='ivory4')
lines(LSTM.CAMELS.US$epoch,
      LSTM.CAMELS.US$train_nse,
      col='darkmagenta')
lines(LSTM.CAMELS.US$epoch,
      LSTM.CAMELS.US$val_mse,
      col='ivory3')
lines(LSTM.CAMELS.US$epoch,
      LSTM.CAMELS.US$val_nse,
      col='darkorchid1')
#legend("bottomright", 
#       legend = c("Tr MSE", "Tr NSE", "Val MSE", "Val NSE",
#                  "Tr MSE w.statatt", "Tr NSE w.statatt", "Val MSE w.statatt", "Val NSE w.statatt",
#                  "Tr MSE LSTM", "Tr NSE LSTM", "Val MSE LSTM", "Val NSE LSTM"), 
#       col = c("firebrick2", "blue3", "lightsalmon", "cadetblue1",
#               "goldenrod3", "olivedrab", "goldenrod1", "olivedrab3",
#               "ivory4", "darkmagenta", "ivory3", "darkorchid1"), 
#       lty = 1,  lwd = 2, box.lwd = 0, box.lty = 0,
#       title = "Performance")
legend("bottomright", 
       legend = c("Tr MSE", "Tr NSE", "Val MSE", "Val NSE",
                  "Tr MSE LSTM", "Tr NSE LSTM", "Val MSE LSTM", "Val NSE LSTM"), 
       col = c("firebrick2", "blue3", "lightsalmon", "cadetblue1",
               "ivory4", "darkmagenta", "ivory3", "darkorchid1"), 
       lty = 1,  lwd = 2, box.lwd = 0, box.lty = 0,
       title = "Performance")



