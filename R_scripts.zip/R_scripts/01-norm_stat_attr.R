#Load libraries
library(dplyr)
library(stringr)

#define directory with CAMELS-US data
dir.CAMELS.US <- 'S:/tina/AML/camels'
#create directory to store normalized selected attributes
dir.create(paste(dir.CAMELS.US,'camels_attributes_v2.0',sep='/'))

#define name of 27 attributes to be retained
clim.att.nm <- c("p_mean", "pet_mean", "aridity", "p_seasonality", "frac_snow", "high_prec_freq", "high_prec_dur", "low_prec_freq", "low_prec_dur")
topo.att.nm <- c("elev_mean","slope_mean","area_gages2")
vege.att.nm <- c("frac_forest", "lai_max", "lai_diff", "gvf_max", "gvf_diff")
soil.att.nm <- c("soil_depth_pelletier", "soil_depth_statsgo", "soil_porosity", "soil_conductivity", "max_water_content", "sand_frac", "silt_frac", "clay_frac")
geol.att.nm <- c("carbonate_rocks_frac", "geol_permeability")

static.att.nm <- c(clim.att.nm, topo.att.nm, vege.att.nm,
                   soil.att.nm, geol.att.nm)

#read static attributes
clim.att <- as.data.frame(read.table(paste(dir.CAMELS.US,'camels_clim.txt', sep='/'), header = TRUE,sep=';',stringsAsFactors=FALSE))
topo.att <- as.data.frame(read.table(paste(dir.CAMELS.US,'camels_topo.txt', sep='/'), header = TRUE,sep=';',stringsAsFactors=FALSE))
vege.att <- as.data.frame(read.table(paste(dir.CAMELS.US,'camels_vege.txt', sep='/'), header = TRUE,sep=';',stringsAsFactors=FALSE))
soil.att <- as.data.frame(read.table(paste(dir.CAMELS.US,'camels_soil.txt', sep='/'), header = TRUE,sep=';',stringsAsFactors=FALSE))
geol.att <- as.data.frame(read.table(paste(dir.CAMELS.US,'camels_geol.txt', sep='/'), header = TRUE,sep=';',stringsAsFactors=FALSE))


#merge and select 27 static attributes
static.att <- cbind.data.frame(clim.att, topo.att, vege.att, soil.att, geol.att)
rm(clim.att); rm(topo.att); rm(vege.att); rm(soil.att); rm(geol.att)

static.att <- select(static.att, c("gauge_id", static.att.nm))
static.att$gauge_id <- str_pad(static.att$gauge_id,8,'left',0)

#select only the columns containing attributes (exclude the ID column)
attributes_df <- select(static.att, -gauge_id)

#normalize the attributes by subtracting the mean and dividing by the standard deviation
normalized_attributes <- mutate(attributes_df, across(everything(), ~ (.-mean(.))/sd(.)))

#combine the ID column with the normalized attributes
static.att.norm <- cbind(str_pad(static.att$gauge_id,8,'left',0),
                         round(normalized_attributes,3), stringsAsFactors=FALSE)
colnames(static.att.norm)[1] <- 'gauge_id'

#Write normalized data
write.table(static.att.norm,
            paste(dir.CAMELS.US,'camels_attributes_v2.0','selected_norm_static_attributes.csv',sep='/'),
            sep=';', row.names = FALSE, col.names = TRUE, quote=FALSE)

#Write original data
static.att$gauge_id <- str_pad(static.att$gauge_id,8,'left',0)
write.table(static.att,
            paste(dir.CAMELS.US,'camels_attributes_v2.0','selected_static_attributes.csv',sep='/'),
            sep=';', row.names = FALSE, col.names = TRUE, quote=FALSE)

#Clear environment
rm(list=ls())

#Now produce something similar to the above but for Switzerland
dir.CAMELS.CH <- 'S:/CAMELS-CH/CAMELS-CH/camels_ch/static_attributes'

#define name of 27 attributes to be retained
clim.att.nm <- c("p_mean", "pet_mean", "aridity", "p_seasonality", "frac_snow", "high_prec_freq", "high_prec_dur", "low_prec_freq", "low_prec_dur")
#topo.att.nm <- c("elev_mean","slope_mean","area")
topo.att.nm <- c("elev_mean","slope_mean","area", "flat_area_perc", "steep_area_perc")
lc.att.nm <- c("grass_perc", "crop_perc", "scrub_perc", "dwood_perc", "mixed_wood_perc", "ewood_perc", "rock_perc", "inwater_perc", "ice_perc")
soil.att.nm <- c("root_depth", "porosity", "conductivity", "tot_avail_water", "sand_perc", "silt_perc", "clay_perc")
hydgeol.att.nm <- c("karst_perc")
geol.att.nm <- c("geo_log10_permeability")
huminf.att.nm <- c("hp_qturb")

#read static attributes
#clim.att <- as.data.frame(read.table(paste(dir.CAMELS.CH,'CAMELS_CH_climate_attributes_obs.csv', sep='/'),
#                                     skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))
clim.att.obs <- as.data.frame(read.table(paste(dir.CAMELS.CH,'CAMELS_CH_climate_attributes_obs.csv', sep='/'),
                                     skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))
clim.att.sim <- as.data.frame(read.table(paste(dir.CAMELS.CH,'simulation_based','CAMELS_CH_climate_attributes_sim.csv', sep='/'),
                                     skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))
topo.att <- as.data.frame(read.delim(paste(dir.CAMELS.CH,'CAMELS_CH_topographic_attributes.csv', sep='/'),
                                     skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))
lc.att <- as.data.frame(read.table(paste(dir.CAMELS.CH,'CAMELS_CH_landcover_attributes.csv', sep='/'),
                                     skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))
soil.att <- as.data.frame(read.table(paste(dir.CAMELS.CH,'CAMELS_CH_soil_attributes.csv', sep='/'),
                                     skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))
hydgeol.att <- as.data.frame(read.table(paste(dir.CAMELS.CH,'CAMELS_CH_hydrogeology_attributes.csv', sep='/'),
                                     skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))
geol.att <- as.data.frame(read.table(paste(dir.CAMELS.CH,'CAMELS_CH_geology_attributes.csv', sep='/'),
                                     skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))
huminf.att <- as.data.frame(read.table(paste(dir.CAMELS.CH,'CAMELS_CH_humaninfluence_attributes.csv', sep='/'),
                                       skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))

lc.att <- select(lc.att, c("gauge_id", lc.att.nm))

lc.att <- lc.att %>%
  mutate(cropwood_perc = crop_perc + scrub_perc + dwood_perc + mixed_wood_perc + ewood_perc + rock_perc,
         .after = grass_perc)

lc.att <- select(lc.att, -c("crop_perc", "scrub_perc", "dwood_perc", "mixed_wood_perc", "ewood_perc"))

lc.att.nm <- colnames(lc.att)[-1]

#Replace missing values with values taken from observations
clim.att.obs[clim.att.obs=='NaN'] <- NA
clim.att.obs[is.na(clim.att.obs)] <- clim.att.sim[is.na(clim.att.obs)]
#Check there are no NAs anymore
any(is.na(clim.att.obs))
#[1] FALSE

clim.att <- clim.att.obs
clim.att$p_seasonality <- as.numeric(clim.att$p_seasonality)
clim.att$frac_snow <- as.numeric(clim.att$frac_snow)
rm(clim.att.obs);rm(clim.att.sim)

static.att.nm <- c(clim.att.nm, topo.att.nm, lc.att.nm,
                   soil.att.nm, hydgeol.att.nm, geol.att.nm, huminf.att.nm)

#merge and select 27 static attributes
static.att <- cbind.data.frame(clim.att, topo.att, lc.att, soil.att, hydgeol.att, geol.att, huminf.att)
#remove lakes
static.att <- static.att[-which(topo.att$water_body_type=="lake"),]
#remove channels where water can flow in both directions
#Zihlkanal: ID 2446
#Canal de la Broye: ID 2447
static.att <- static.att[-match(c(2446,2447),static.att$gauge_id),]

rm(clim.att); rm(topo.att); rm(lc.att); rm(soil.att); rm(geol.att); rm(hydgeol.att); rm(huminf.att)

static.att <- select(static.att, c("gauge_id", static.att.nm))

#Remove data with NaN (mainly in other neighbouring countries => why is that??)
#static.att <- static.att[-which(static.att$p_seasonality=="NaN"),]

#select only the columns containing attributes (exclude the ID column)
attributes_df <- select(static.att, -gauge_id)

#normalize the attributes by subtracting the mean and dividing by the standard deviation
normalized_attributes <- mutate(attributes_df, across(everything(), ~ (.-mean(.))/sd(.)))

#combine the ID column with the normalized attributes
static.att.norm <- cbind(static.att$gauge_id, normalized_attributes)
colnames(static.att.norm)[1] <- 'gauge_id'

#Write normalized data
write.table(round(static.att.norm,3),
            paste(dir.CAMELS.CH,'selected296_norm_static_attributes.csv',sep='/'),
            sep=';', row.names = FALSE, col.names = TRUE, quote=FALSE)

write.table(static.att.norm$gauge_id, 'S:/tina/AML/P3/RR-Former/data/298basins_list.txt',
            quote=FALSE, row.names = FALSE, col.names = FALSE)

#Write original data
write.table(round(static.att,3),
            paste(dir.CAMELS.CH,'selected298_static_attributes.csv',sep='/'),
            sep=';', row.names = FALSE, col.names = TRUE, quote=FALSE)


library(data.table)

# Check how much data are available in CAMELS-CH
# and keep only catchments with at least 90% data coverage
#basins <- read.table('S:/tina/AML/P3/RR-Former/data/244basins_list.txt')
basins <- read.table('S:/tina/AML/P3/RR-Former/data/296basins_list.txt')
basins <- basins$V1
  
fn.obs <- list.files("S:/CAMELS-CH/CAMELS-CH/camels_ch/timeseries/observation_based", full.names = TRUE)
#fn.sim <- list.files("S:/CAMELS-CH/CAMELS-CH/camels_ch/timeseries/simulation_based", full.names = TRUE)

basins2keep <- c("")

#training.period <- 
#validation.period <-
#testing.period <- 

#i=250

for (i in 1:length(basins)) {
  
  data.obs <- as.data.frame(fread(fn.obs [grep(basins[i],fn.obs)],header=TRUE), stringsAsFactors=FALSE)
  data.obs$`discharge_spec(mm/d)`[which(data.obs$`discharge_spec(mm/d)`=="NaN")] <- NA
  
  #data.sim <- as.data.frame(fread(fn.sim [grep(basins[i],fn.sim )],header=TRUE), stringsAsFactors=FALSE)
  #data.sim$`discharge_spec(mm/d)`[which(data.sim$`discharge_spec(mm/d)`=="NaN")] <- NA
  
  #if (length(which(!is.na(data.obs$`discharge_spec(mm/d)`)))/length(data.obs$`discharge_spec(mm/d)`)>0.9) {
  if (length(which(!is.na(data.obs$`discharge_spec(mm/d)`)))/length(data.obs$`discharge_spec(mm/d)`)>0.75) {
    
    #print(paste(basins[i]," has overall more than 90% data coverage!"))
    print(paste(basins[i]," has overall at least than 75% data coverage!"))
    
    basins2keep <- c(basins2keep, basins[i])
    
  }
  
  
}


for (i in 1:length(basins)) {
  
  data.obs <- as.data.frame(fread(fn[grep(basins[i],fn)],header=TRUE), stringsAsFactors=FALSE)
  data.obs$`discharge_spec(mm/d)`[which(data.obs$`discharge_spec(mm/d)`=="NaN")] <- NA
  
  if (length(which(!is.na(data.obs$`discharge_spec(mm/d)`)))/length(data.obs$`discharge_spec(mm/d)`)>0.25) {
    
    print(paste(basins[i]," has more than 25% data coverage!"))
    
    basins2keep <- c(basins2keep, basins[i])
    
  }
  
}

basins2keep <- basins2keep[-1]

write.table(basins2keep, 'S:/tina/AML/P3/RR-Former/data/219basins_list.txt',
            quote=FALSE, row.names = FALSE, col.names = FALSE)


# Check how much data are available in CAMELS-US
# and keep only catchments with at elast 90% data coverage
#define directory with CAMELS-US data
basins <- read.table('S:/tina/AML/RR-Former/data/671basins_list.txt')
basins <- basins$V1
basins <- str_pad(basins,8,'left',0)

fn <- list.files("S:/tina/AML/camels/basin_timeseries_v1p2_metForcing_obsFlow/basin_dataset_public_v1p2/usgs_streamflow",
                 full.names = TRUE, recursive = TRUE, include.dirs = FALSE)

basins2keep <- c("")

for (i in 1:length(basins)) {
  
  data.obs <- as.data.frame(fread(fn[grep(basins[i],fn)],header = FALSE), stringsAsFactors=FALSE)
  data.obs$V5[which(data.obs$V5 < 0)] <- NA
  
  if (length(which(!is.na(data.obs$V5)))/length(data.obs$V5)>0.9) {
    
    print(paste(basins[i]," has more than 90% data coverage!"))
    
    basins2keep <- c(basins2keep, basins[i])
    
  }
  
}

basins2keep <- basins2keep[-1]

write.table(basins2keep, 'S:/tina/AML/RR-Former/data/662basins_list.txt',
            quote=FALSE, row.names = FALSE, col.names = FALSE)

#Remove arid basins?

#define directory with CAMELS-US data
dir.CAMELS.US <- 'S:/tina/AML/camels'
#read climatic attributes
clim.att <- as.data.frame(read.table(paste(dir.CAMELS.US,'camels_clim.txt', sep='/'),
                                     header = TRUE,sep=';',stringsAsFactors=FALSE))
length(which(clim.att$aridity>1))
#[1] 235

basins.nonarid <- str_pad(clim.att$gauge_id[which(clim.att$aridity<=1)],8,'left',0)
basins2keep <- basins.nonarid[which(basins.nonarid %in% basins2keep)]

write.table(basins2keep, 'S:/tina/AML/RR-Former/data/431basins_list.txt',
            quote=FALSE, row.names = FALSE, col.names = FALSE)


#Plot data, for some reason in the validation period things look weird.
#Note: it would be worth picking another validation period and see if the wavy problem in NSE persists?
#Also: use KGE instead of NSE or the new non-conformity NSE by Kratzert&co?


#CAMELS US
basins <- read.table('S:/tina/AML/RR-Former/data/431basins_list.txt')
basins <- basins$V1
basins <- str_pad(basins,8,'left',0)

fn <- list.files("S:/tina/AML/camels/basin_timeseries_v1p2_metForcing_obsFlow/basin_dataset_public_v1p2/usgs_streamflow",
                 full.names = TRUE, recursive = TRUE, include.dirs = FALSE)

for (i in 1:length(basins)) {
  
  data.obs <- as.data.frame(fread(fn[grep(basins[i],fn)],header = FALSE), stringsAsFactors=FALSE)
  data.obs$V5[which(data.obs$V5 < 0)] <- NA
  
  time.data <- as.POSIXct(paste0(data.obs$V2,'-',data.obs$V3,'-',data.obs$V4),
                          format="%Y-%m-%d",tz='UTC')
  
  time <- seq(as.POSIXct(paste0(data.obs$V2[1],'-',data.obs$V3[1],'-',data.obs$V4[1]),
                         format="%Y-%m-%d",tz='UTC'),
              as.POSIXct(paste0(data.obs$V2[dim(data.obs)[1]],'-',data.obs$V3[dim(data.obs)[1]],'-',data.obs$V4[dim(data.obs)[1]]),
                         format="%Y-%m-%d",tz='UTC'),by=24*3600)
  
  #Check if time is the same
  #df1 <- as.Date(time.data)
  #df2 <- as.Date(time )
  
  # Find duplicated dates in the first time series
  #duplicated_dates <- df1[duplicated(df1)]
  
  # Find dates in the first time series that are not present in the second time series
  #missing_dates <- setdiff(df1, df2)
  
  # Print or use the results as needed
  #print("Duplicated dates in the first time series:")
  #print(duplicated_dates)
  #print("\nDates in the first time series not present in the second time series:")
  #print(missing_dates)
  
  #which(time==as.POSIXct("1995-10-01",format="%Y-%m-%d",tz='UTC'))
  time.val <- c(as.POSIXct("1995-10-01",format="%Y-%m-%d",tz='UTC'),
                as.POSIXct("1995-10-01",format="%Y-%m-%d",tz='UTC'))
  time.test <- c(as.POSIXct("2000-10-01",format="%Y-%m-%d",tz='UTC'),
                 as.POSIXct("2000-10-01",format="%Y-%m-%d",tz='UTC'))
  y <- c(0,1000000)
  
  plot(time, data.obs$V5,
       xlab = 'time', ylab = expression("Q [ft"^3*"/s]"),mgp = c(2, 1, 0),
       type='l', col='blue')
  title(paste('Basin #', i, ", ID",basins[i]))
  lines(time.val, y, lty=2, col='grey')
  lines(time.test, y, lty=2, col='grey')
  
}

#CAMELS CH
basins <- read.table('S:/tina/AML/P3/RR-Former/data/170basins_list.txt')
basins <- basins$V1

fn <- list.files("S:/CAMELS-CH/CAMELS-CH/camels_ch/timeseries/observation_based", full.names = TRUE)

for (i in 1:length(basins)) {
  
  data.obs <- as.data.frame(fread(fn[grep(basins[i],fn)],header=TRUE), stringsAsFactors=FALSE)
  data.obs$`discharge_spec(mm/d)`[which(data.obs$`discharge_spec(mm/d)`=="NaN")] <- NA
  
  time <- as.POSIXct(data.obs$date,
                     format="%Y-%m-%d",tz='UTC')
  
  time.val <- c(as.POSIXct("1995-10-01",format="%Y-%m-%d",tz='UTC'),
                as.POSIXct("1995-10-01",format="%Y-%m-%d",tz='UTC'))
  time.test <- c(as.POSIXct("2000-10-01",format="%Y-%m-%d",tz='UTC'),
                 as.POSIXct("2000-10-01",format="%Y-%m-%d",tz='UTC'))
  
  y <- c(0,1000000)
  
  plot(time, data.obs$`discharge_spec(mm/d)`,
       xlab = 'time', ylab = "Q [mm/d]", mgp = c(2, 1, 0),
       type='l', col='blue')
  title(paste('Basin', basins[i]))
  lines(time.val, y, lty=2, col='grey')
  lines(time.test, y, lty=2, col='grey')
  
}

         
#> 33*170
#[1] 5610
#> 1003098/170
#[1] 5900.576
#> 5900/365
#[1] 16.16438
length(seq(as.POSIXct(paste0(1980,'-',10,'-',1),format="%Y-%m-%d",tz='UTC'),
           as.POSIXct(paste0(1995,'-',09,'-',30),format="%Y-%m-%d",tz='UTC'),by=3600*24))#Get how many time steps 
#[1] 5478
length(seq(as.POSIXct(paste0(1995,'-',10,'-',1),format="%Y-%m-%d",tz='UTC'),
           as.POSIXct(paste0(2000,'-',09,'-',30),format="%Y-%m-%d",tz='UTC'),by=3600*24))#Get how many time steps 
#[1] 1827
381407/(170*34)


#Prepare data only for the basins to keep

#Get list with CAMELS CH catchments
basins <- read.table('S:/tina/AML/P3/RR-Former/data/219basins_list.txt')
basins <- basins$V1

dir.CAMELS.CH <- 'S:/CAMELS-CH/CAMELS-CH/camels_ch/static_attributes'

#define name of 27 attributes to be retained
clim.att.nm <- c("p_mean", "pet_mean", "aridity", "p_seasonality", "frac_snow", "high_prec_freq", "high_prec_dur", "low_prec_freq", "low_prec_dur")
#topo.att.nm <- c("elev_mean","slope_mean","area")
topo.att.nm <- c("elev_mean","slope_mean","area", "flat_area_perc", "steep_area_perc")
lc.att.nm <- c("grass_perc", "crop_perc", "scrub_perc", "dwood_perc", "mixed_wood_perc", "ewood_perc", "rock_perc", "inwater_perc", "ice_perc")
soil.att.nm <- c("root_depth", "porosity", "conductivity", "tot_avail_water", "sand_perc", "silt_perc", "clay_perc")
hydgeol.att.nm <- c("karst_perc")
geol.att.nm <- c("geo_log10_permeability")
huminf.att.nm <- c("hp_qturb")

#read static attributes
#clim.att <- as.data.frame(read.table(paste(dir.CAMELS.CH,'CAMELS_CH_climate_attributes_obs.csv', sep='/'),
#                                     skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))
clim.att.obs <- as.data.frame(read.table(paste(dir.CAMELS.CH,'CAMELS_CH_climate_attributes_obs.csv', sep='/'),
                                         skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))
clim.att.sim <- as.data.frame(read.table(paste(dir.CAMELS.CH,'simulation_based','CAMELS_CH_climate_attributes_sim.csv', sep='/'),
                                         skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))
topo.att <- as.data.frame(read.delim(paste(dir.CAMELS.CH,'CAMELS_CH_topographic_attributes.csv', sep='/'),
                                     skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))
lc.att <- as.data.frame(read.table(paste(dir.CAMELS.CH,'CAMELS_CH_landcover_attributes.csv', sep='/'),
                                   skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))
soil.att <- as.data.frame(read.table(paste(dir.CAMELS.CH,'CAMELS_CH_soil_attributes.csv', sep='/'),
                                     skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))
hydgeol.att <- as.data.frame(read.table(paste(dir.CAMELS.CH,'CAMELS_CH_hydrogeology_attributes.csv', sep='/'),
                                        skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))
geol.att <- as.data.frame(read.table(paste(dir.CAMELS.CH,'CAMELS_CH_geology_attributes.csv', sep='/'),
                                     skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))
huminf.att <- as.data.frame(read.table(paste(dir.CAMELS.CH,'CAMELS_CH_humaninfluence_attributes.csv', sep='/'),
                                       skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))

lc.att <- select(lc.att, c("gauge_id", lc.att.nm))

lc.att <- lc.att %>%
  mutate(cropwood_perc = crop_perc + scrub_perc + dwood_perc + mixed_wood_perc + ewood_perc + rock_perc,
         .after = grass_perc)

lc.att <- select(lc.att, -c("crop_perc", "scrub_perc", "dwood_perc", "mixed_wood_perc", "ewood_perc"))

lc.att.nm <- colnames(lc.att)[-1]

#Replace missing values with values taken from observations
clim.att.obs[clim.att.obs=='NaN'] <- NA
clim.att.obs[is.na(clim.att.obs)] <- clim.att.sim[is.na(clim.att.obs)]
#Check there are no NAs anymore
any(is.na(clim.att.obs))
#[1] FALSE

clim.att <- clim.att.obs
clim.att$p_seasonality <- as.numeric(clim.att$p_seasonality)
clim.att$frac_snow <- as.numeric(clim.att$frac_snow)
rm(clim.att.obs);rm(clim.att.sim)

static.att.nm <- c(clim.att.nm, topo.att.nm, lc.att.nm,
                   soil.att.nm, hydgeol.att.nm, geol.att.nm, huminf.att.nm)

#merge and select 27 static attributes
static.att <- cbind.data.frame(clim.att, topo.att, lc.att, soil.att, hydgeol.att, geol.att, huminf.att)
#remove lakes
static.att <- static.att[-which(topo.att$water_body_type=="lake"),]
#remove channels where water can flow in both directions
#Zihlkanal: ID 2446
#Canal de la Broye: ID 2447
static.att <- static.att[-match(c(2446,2447),static.att$gauge_id),]

rm(clim.att); rm(topo.att); rm(lc.att); rm(soil.att); rm(geol.att); rm(hydgeol.att); rm(huminf.att)

static.att <- select(static.att, c("gauge_id", static.att.nm))

static.att <- static.att %>% filter(gauge_id %in% basins)

#Remove data with NaN (mainly in other neighbouring countries => why is that??)
#static.att <- static.att[-which(static.att$p_seasonality=="NaN"),]

#select only the columns containing attributes (exclude the ID column)
attributes_df <- select(static.att, -gauge_id)

#normalize the attributes by subtracting the mean and dividing by the standard deviation
normalized_attributes <- mutate(attributes_df, across(everything(), ~ (.-mean(.))/sd(.)))

#combine the ID column with the normalized attributes
static.att.norm <- cbind(static.att$gauge_id, normalized_attributes)
colnames(static.att.norm)[1] <- 'gauge_id'

#Write normalized data
write.table(round(static.att.norm,3),
            paste(dir.CAMELS.CH,'selected219_norm_static_attributes.csv',sep='/'),
            sep=';', row.names = FALSE, col.names = TRUE, quote=FALSE)

#Write original data
write.table(round(static.att,3),
            paste(dir.CAMELS.CH,'selected219_static_attributes.csv',sep='/'),
            sep=';', row.names = FALSE, col.names = TRUE, quote=FALSE)


