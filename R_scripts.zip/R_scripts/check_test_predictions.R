
# CAMELS-USA
runs.dir <- "S:/tina/AML/RR-Former/runs"
model <- "LSTMMSVS2S"
list.dirs(runs.dir,recursive=FALSE)[grep("LSTM",list.dirs(runs.dir,recursive=FALSE))]
LSTMMSVS2S_[[22-7-32-128][15-%-1-128][%-7-256-128]-0.2]@daymet431_1980~1995#1995~2000#2000~2014@22_15+7[32+1]@NSELoss_n150_bs512_lr0.001_warm_up@seedNone\fine_tune
basin.ID <- "01013500"
obspred.dir <- "obs_pred"


# CAMELS-CH