###########################################
#####    Define streamflow regime     #####
#####  according to decision tree by  #####
#####  Aschwanden &Weingartner 1985   #####
###########################################

#Load libraries
library(raster)
library(sf)
library(exactextractr)
library(dplyr)
library(rio)

# Catchments CAMELS CH
catchs.shp <- st_read('S:/CAMELS-CH/CAMELS-CH/camels_ch/catchment_delineations/CAMELS_CH_catchments_mod_geomfix.shp')

# Outlets CAMELS CH
outlet.shp <- st_read('S:/CAMELS-CH/CAMELS-CH/camels_ch/catchment_delineations/CAMELS_CH_gauging_stations_mod.shp')

#     Streamflow regime

# for gwn
QregMQ <- st_read('D:/GIS/MQ-GWN-CH/Datensatz/MQ_GWN_CH_join_CH1903.shp')
QregMQ <-st_transform(QregMQ,st_crs(catchs.shp))
QregGewTyp <- st_read('D:/GIS/Fliessgewaessertypisierung/FGT_CH1903.shp')
QregGewTyp <-st_transform(QregGewTyp,st_crs(catchs.shp))

#     Basis regions for discharge regime
BasReg.Qreg <- st_read('J:/EXAR-CH/GIS/Grundregionen_AbflReg.shp')
BasReg.Qreg  <-st_transform(BasReg.Qreg ,st_crs(catchs.shp))

#Set directory where static_ attrites are stored
dir.CAMELS.CH <- 'S:/CAMELS-CH/CAMELS-CH/camels_ch/static_attributes'

#read static attributes
#topographic
topo.att <- as.data.frame(read.delim(paste(dir.CAMELS.CH,'CAMELS_CH_topographic_attributes.csv', sep='/'),
                                     skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))
#landcover
lc.att <- as.data.frame(read.table(paste(dir.CAMELS.CH,'CAMELS_CH_landcover_attributes.csv', sep='/'),
                                   skip=1, header = TRUE,sep=',',stringsAsFactors=FALSE))

attr <- readRDS('S:/tina/AML/P3/attr_missing2.rds')
attr <- attr %>% mutate(LARGE_BASIN=rep(" ",nrow(attr)),.after=gauge_id)

#Retain only missing catchments and gauging point 
catchs.shp <- catchs.shp[match(attr$gauge_id,catchs.shp$gauge_id),]
outlet.shp <- outlet.shp[match(attr$gauge_id,outlet.shp$gauge_id),]

catchs.shp[match(attr$gauge_id,catchs.shp$gauge_id),c('gauge_id','water_body','country')]

LargeBasins <- st_read('D:/GIS/HADES/major_rivers_hydroCH.shp',stringsAsFactors=FALSE)
LargeBasins <-st_transform(LargeBasins,st_crs(catchs.shp))
#Extract basis region based on majority?
LargeBasins.int <- st_intersection(LargeBasins,catchs.shp)
for (catch.i in 1:nrow(catchs.shp)) {
  
  catch.sel <- catchs.shp[catch.i,]
  
  print(paste0("#",catch.i,": ",catch.sel$gauge_id," ",
               catch.sel$water_body,"-",catch.sel$gauge_name))
  
  area.frac <- as.numeric(st_area(LargeBasins.int[which(LargeBasins.int$gauge_id==attr$gauge_id[catch.i]),]))/
    st_drop_geometry(LargeBasins.int[which(LargeBasins.int$gauge_id==attr$gauge_id[catch.i]),"Shape_Area"])
  
  attr$LARGE_BASIN[catch.i] <- st_drop_geometry(LargeBasins.int[which(LargeBasins.int$gauge_id==attr$gauge_id[catch.i]),"X3FLUSSGEna"])[which.max(area.frac$Shape_Area),"X3FLUSSGEna"]
  
  print(paste0("Large basin"," ",attr$LARGE_BASIN[catch.i]))
  
  rm(area.frac)
  
}

attr$LARGE_BASIN[which(attr$LARGE_BASIN=="Adda and Adige")] <- "Adda"
rm(LargeBasins);rm(LargeBasins.int)

#Extract basis region based on majority?
BasReg.Qreg.int <- st_intersection(BasReg.Qreg,catchs.shp)
attr <- attr %>% mutate(BasRegQregMaj=rep(0,nrow(attr)),.after=Klimaregio_all)

for (catch.i in 1:nrow(catchs.shp)) {
  
  catch.sel <- catchs.shp[catch.i,]
  
  print(paste0("#",catch.i,": ",catch.sel$gauge_id," ",
               catch.sel$water_body,"-",catch.sel$gauge_name))
  
  area.frac <- as.numeric(st_area(BasReg.Qreg.int[which(BasReg.Qreg.int$gauge_id==attr$gauge_id[catch.i]),]))/
    st_drop_geometry(BasReg.Qreg.int[which(BasReg.Qreg.int$gauge_id==attr$gauge_id[catch.i]),"Shape_Area"])
  
  attr$BasRegQregMaj[catch.i] <- st_drop_geometry(BasReg.Qreg.int[which(BasReg.Qreg.int$gauge_id==attr$gauge_id[catch.i]),"Grundreg"])[which.max(area.frac$Shape_Area),"Grundreg"]
  
  print(paste0("BasReg.Qreg"," ",attr$BasRegQregMaj[catch.i]))
  
  rm(area.frac)
  
}

rm(catch.i);rm(catch.sel)

#Extract basis region based on mere overlay
attr <- attr %>% mutate(BasRegQreg=rep(0,nrow(attr)))

BasReg.Qreg.int <- st_intersection(outlet.shp,BasReg.Qreg)

attr$BasRegQreg[match(BasReg.Qreg.int$gauge_id,attr$gauge_id)] <- BasReg.Qreg.int$Grundreg

rm(BasReg.Qreg);rm(BasReg.Qreg.int)

attr$BasRegQreg[which(attr$BasRegQreg==0)] <- attr$BasRegQregMaj[which(attr$BasRegQreg==0)]

attr <- attr %>% mutate(ice_perc=lc.att$ice_perc[match(attr$gauge_id,lc.att$gauge_id)])
attr <- attr %>% mutate(elev_mean=topo.att$elev_mean[match(attr$gauge_id,topo.att$gauge_id)])

IBCHQREGIM <- QregGewTyp[st_nearest_feature(outlet.shp,QregGewTyp),'IBCHQREGIM']
regMQ <- QregMQ[st_nearest_feature(outlet.shp,QregMQ),c('regimetyp','regimenr')]

attr <- attr %>% mutate(AbflregIBCH=rep(0,nrow(attr)))
attr <- attr %>% mutate(Abflreg=rep(0,nrow(attr)))

### Define the regime type depending on 
### catchments'characteristics (discharge base region, mean elevation and glaciation)

# Regime type

for (i in 1:nrow(attr)) {
  
  #print(paste0('Catch nr. ',i))
  #print(paste0('Processing catch: ',catchs.shp$ID12[i]))
  #print(paste0(catchs.shp$RIVER_NAME[i],'@',catchs.shp$SITE_NAME[i]))
  
  if (attr[i,'BasRegQreg'] == 1 & attr[i,'elev_mean'] > 1550) {
    
    if (any(attr$LARGE_BASIN[i] == unique(attr$LARGE_BASIN)[grep('Rhein',unique(attr$LARGE_BASIN))] |
            attr$LARGE_BASIN[i] == 'Rhone')) {
      
      # a-glaciaire
      if (attr[i,'elev_mean'] > 2400 & 
          attr[i,'ice_perc'] > 36){attr[i,'Abflreg'] = 1}
      if (attr[i,'elev_mean'] > 1900 & 
          attr[i,'ice_perc'] > 38){attr[i,'AbflregIBCH'] = 1}
      
      # b-glaciaire
      if (attr[i,'elev_mean'] > 2100 & 
          attr[i,'ice_perc'] <= 40 & attr[i,'ice_perc'] > 22){attr[i,'Abflreg'] = 2}
      if (attr[i,'elev_mean'] > 1900 & 
          attr[i,'ice_perc'] <= 38 & attr[i,'ice_perc'] > 22){attr[i,'AbflregIBCH'] = 2}
      
      # a-glacio-nival
      if (attr[i,'elev_mean'] > 2000 & 
          attr[i,'ice_perc'] <= 22 & attr[i,'ice_perc'] > 12){attr[i,'Abflreg'] = 3}
      if (attr[i,'elev_mean'] > 1900 & 
          attr[i,'ice_perc'] <= 22 & attr[i,'ice_perc'] > 12){attr[i,'AbflregIBCH'] = 3}
      
      # b-glacio-nival
      if (attr[i,'elev_mean'] > 1900 & 
          attr[i,'ice_perc'] <= 12 & attr[i,'ice_perc'] > 6)  {
        attr[i,'Abflreg'] = 4
        attr[i,'AbflregIBCH'] = 4}
      if (attr[i,'elev_mean'] > 2300 & 
          attr[i,'ice_perc'] <= 12 & attr[i,'ice_perc'] > 1)  {
        attr[i,'Abflreg'] = 4
        attr[i,'AbflregIBCH'] = 4}
      
      # nivo-glaciaire
      if (attr[i,'elev_mean'] > 1550 & 
          attr[i,'elev_mean'] <= 1900 & 
          attr[i,'ice_perc'] <= 12 & 
          attr[i,'ice_perc'] > 3)  {
        attr[i,'Abflreg'] = 5
        attr[i,'AbflregIBCH'] = 5}
      if (attr[i,'elev_mean'] > 1900 & 
          attr[i,'elev_mean'] <= 2300 &
          attr[i,'ice_perc'] <= 6
          & attr[i,'ice_perc'] > 1)  {
        attr[i,'Abflreg'] = 5
        attr[i,'AbflregIBCH'] = 5}
      
      # nival alpin
      if (attr[i,'elev_mean'] > 1550 & attr[i,'elev_mean'] <= 1900 &
          attr[i,'ice_perc'] <= 3)  {
        attr[i,'Abflreg'] = 6
        attr[i,'AbflregIBCH'] = 6}
      if (attr[i,'elev_mean'] > 1900 &
          attr[i,'ice_perc'] <= 1)  {
        attr[i,'Abflreg'] = 6
        attr[i,'AbflregIBCH'] = 6}
    }
    
    if (attr$LARGE_BASIN[i] == 'Inn') {
      
      # a-glaciaire
      if (attr[i,'elev_mean'] > 2400 & 
          attr[i,'ice_perc'] > 30){
        attr[i,'Abflreg'] = 1
        attr[i,'AbflregIBCH'] = 1}
      
      # b-glaciaire
      if (attr[i,'elev_mean'] > 2100 & 
          attr[i,'ice_perc'] <= 30 & attr[i,'ice_perc'] > 20){
        attr[i,'Abflreg'] = 2
        attr[i,'AbflregIBCH'] = 2}
      
      # a-glacio-nival
      if (attr[i,'elev_mean'] > 2000 & 
          attr[i,'ice_perc'] <= 20 & attr[i,'ice_perc'] > 12){
        attr[i,'Abflreg'] = 3
        attr[i,'AbflregIBCH'] = 3}
      
      # b-glacio-nival
      if (attr[i,'elev_mean'] > 2300 & 
          attr[i,'ice_perc'] <= 12 & attr[i,'ice_perc'] > 6)  {
        attr[i,'Abflreg'] = 4
        attr[i,'AbflregIBCH'] = 4}
      
      # nivo-glaciaire
      if (attr[i,'elev_mean'] > 1550 & 
          attr[i,'elev_mean'] <= 1900 & 
          attr[i,'ice_perc'] <= 12 & 
          attr[i,'ice_perc'] > 3)  {attr[i,'Abflreg'] = 5}
      if (attr[i,'elev_mean'] > 2300 & 
          attr[i,'ice_perc'] <= 6
          & attr[i,'ice_perc'] > 1)  {
        attr[i,'Abflreg'] = 5
        attr[i,'AbflregIBCH'] = 5}
      if (attr[i,'elev_mean'] > 1550 & 
          attr[i,'elev_mean'] <= 2300 & 
          attr[i,'ice_perc'] <= 12 & 
          attr[i,'ice_perc'] > 3)  {attr[i,'AbflregIBCH'] = 5}
      if (attr[i,'elev_mean'] > 2100 & 
          attr[i,'elev_mean'] <= 2300 & 
          attr[i,'ice_perc'] <= 3
          & attr[i,'ice_perc'] > 1)  {attr[i,'AbflregIBCH'] = 5}
      
      # nival alpin
      if (attr[i,'elev_mean'] > 1550 & attr[i,'elev_mean'] <= 1900 &
          attr[i,'ice_perc'] <= 3)  {attr[i,'Abflreg'] = 6}
      if (attr[i,'elev_mean'] > 2300 &
          attr[i,'ice_perc'] <= 1)  {attr[i,'Abflreg'] = 6}
      if (attr[i,'elev_mean'] > 1550 & attr[i,'elev_mean'] <= 2100 &
          attr[i,'ice_perc'] <= 3)  {attr[i,'AbflregIBCH'] = 6}
      if (attr[i,'elev_mean'] > 1550 &
          attr[i,'ice_perc'] <= 1)  {attr[i,'AbflregIBCH'] = 6}
      
    }
    
  }
  
  if (attr[i,'BasRegQreg'] == 1 & attr[i,'elev_mean'] <= 1550) {
    # nival de transition
    if (attr[i,'elev_mean'] > 1250 & attr[i,'elev_mean'] <= 1550)  {
      attr[i,'Abflreg'] = 7
      attr[i,'AbflregIBCH'] = 7}
    
    # nivo-pluvial  prealpine
    if (attr[i,'elev_mean'] > 900 & attr[i,'elev_mean'] <= 1350)  {
      attr[i,'Abflreg'] = 8
      attr[i,'AbflregIBCH'] = 8}
    
    # pluvial sup?rieur
    if (attr[i,'elev_mean'] > 700 & attr[i,'elev_mean'] <= 900)  {
      attr[i,'Abflreg'] = 9
      attr[i,'AbflregIBCH'] = 9}
    
    # pluvial inf?rieur
    if (attr[i,'elev_mean'] < 750)  {
      attr[i,'Abflreg'] = 10
      attr[i,'AbflregIBCH'] = 10}
  }
  
  if (attr[i,'BasRegQreg'] == 2) {
    
    # pluvial jurassien
    if (attr[i,'elev_mean'] > 800 & attr[i,'elev_mean'] <= 1700 &
        attr[i,'ice_perc'] == 0)  {attr[i,'Abflreg'] = 11}
    
    # nivo-pluvial jurassien
    if (attr[i,'elev_mean'] < 900 & attr[i,'ice_perc'] == 0)  {attr[i,'Abflreg'] = 12}
    
    # pluvial jurassien
    if (attr[i,'elev_mean'] > 950 & attr[i,'ice_perc'] == 0)  {attr[i,'AbflregIBCH'] = 11}
    
    # nivo-pluvial jurassien
    if (attr[i,'elev_mean'] <= 950 & attr[i,'ice_perc'] == 0)  {attr[i,'AbflregIBCH'] = 12}
    
  }
  
  if (attr[i,'BasRegQreg'] == 3) {
    
    # glaciaire m?ridional
    if (attr[i,'elev_mean'] >= 2300 & attr[i,'ice_perc'] > 20)  {
      attr[i,'Abflreg'] = 17
      attr[i,'AbflregIBCH'] = 18}
    
    # glacio-nival m?ridional
    if (attr[i,'elev_mean'] >= 1800 &
        attr[i,'ice_perc'] <= 20 &
        attr[i,'ice_perc'] > 6 )  {
      attr[i,'Abflreg'] = 18
      attr[i,'AbflregIBCH'] = 19}
    
    # nival m?ridional
    #if (attr[i,'elev_mean'] <= 2300 &
    if (attr[i,'elev_mean'] <= 2600 &
        attr[i,'elev_mean'] > 1800 &
        attr[i,'ice_perc'] <= 6 &
        attr[i,'ice_perc'] >= 0 )  {
      attr[i,'Abflreg'] = 13
      attr[i,'AbflregIBCH'] = 13}
    
    # nivo-pluvial m?ridional
    if (attr[i,'elev_mean'] > 1200 & attr[i,'elev_mean'] <= 1800)  {
      attr[i,'Abflreg'] = 14
      attr[i,'AbflregIBCH'] = 14}
    
    # pluvio-nival m?ridional
    if (attr[i,'elev_mean'] > 700 & attr[i,'elev_mean'] <= 1200)  {
      attr[i,'Abflreg'] = 15
      attr[i,'AbflregIBCH'] = 15}
    
    # pluvial m?ridional
    #if (attr[i,'elev_mean'] > 300 & attr[i,'elev_mean'] <= 700)  {
    if (attr[i,'elev_mean'] > 190 & attr[i,'elev_mean'] <= 700)  {
      attr[i,'Abflreg'] = 16
      attr[i,'AbflregIBCH'] = 16}
    
  }
  
  #print(paste0('Abflreg: ',attr[i,'Abflreg']))
  #print(paste0('IBCHQREGIM: ',attr[i,'IBCHQREGIM'])) 
  
}


#Some gauging stations are still missing the streamflow regime!
#Let's remediate this:
#Get catchment inventory (from EXCH project)
catchs.inv <- as.data.frame(import_list('P:/Hydrologie/EXAR-CH/EXCH_datasets-main/inventory+metadata_dischargedata_stations/Inventar_hydrologische_Daten_EXCH.xlsx',
                                        which = "ALL", rbind = FALSE),stringsAsFactors=FALSE)
colnames(catchs.inv) <- gsub('ALL.','',colnames(catchs.inv))
catchs.inv[,'ID12'] <- sapply(catchs.inv[,'ID12'],as.character)
#Get attributes extracted for subcatchments in EXCH
attr.all <- readRDS('S:/tina/AML/P3/attrALL.rds')
#Get streamflow regime from neighboring stations if it could be defined:
attr$Abflreg[attr$gauge_id==2130] <- attr.all$Abflreg[which(attr.all$ID12==catchs.inv$ID12[which(catchs.inv$OPERATOR_ID==2091)])]
attr$Abflreg[attr$gauge_id==2613] <- attr.all$Abflreg[which(attr.all$ID12==catchs.inv$ID12[which(catchs.inv$OPERATOR_ID==2289)])]
attr$Abflreg[attr$gauge_id==2615] <- attr.all$Abflreg[which(attr.all$ID12==catchs.inv$ID12[which(catchs.inv$OPERATOR_ID==2289)])]
attr$Abflreg[attr$gauge_id==2217] <- attr.all$Abflreg[which(attr.all$ID12==catchs.inv$ID12[which(catchs.inv$OPERATOR_ID==2174)])]
#attr$Abflreg[attr$gauge_id==6011] <- 16 #not really sure about this one..

#Add streamflow regime names
AbflReg.lookuptable <- setNames(cbind.data.frame(seq(1,18,1),
                                                 c("01 a-glaciaire","02 b-glaciaire","03 a-glacio-nival",
                                                   "04 b-glacio-nival","05 nivo-glaciaire","06 nival alpin",
                                                   "07 nival de transition","08 nivo-pluvial prealpin","09 pluvial superieur",
                                                   "10 pluvial inferieur","11 pluvial jurassien","12 nivo-pluvial jurassien",
                                                   "13 nival meridional","14 nivo-pluvial meridional","15 pluvio-nival meridional",
                                                   "16 pluvial meridional","17 glaciaire meridional","18 glacio-nival meridional"),
                                                 stringsAsFactors=FALSE),
                                c('AbflReg.Nr','AbflReg.Type'))

attr <- attr %>% mutate(Abflreg_nm=rep(" ",nrow(attr)))

attr$Abflreg_nm <- AbflReg.lookuptable[match(attr$Abflreg,AbflReg.lookuptable$AbflReg.Nr),'AbflReg.Type']

#Remove columns you don't need
attr<- attr[,-which(colnames(attr)=='AbflregIBCH')]

saveRDS(attr, 'S:/tina/AML/P3/attr_missing2.rds')
