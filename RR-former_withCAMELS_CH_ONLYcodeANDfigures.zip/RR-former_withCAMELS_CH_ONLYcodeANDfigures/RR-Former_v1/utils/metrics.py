# All metrics needs obs and sim shape: (batch_size, pred_len, tgt_size)

import numpy as np
import torch


def calc_nse(obs: np.array, sim: np.array) -> np.array:
    denominator = np.sum((obs - np.mean(obs, axis=0)) ** 2, axis=0)
    numerator = np.sum((sim - obs) ** 2, axis=0)
    nse = 1 - numerator / denominator

    nse_mean = np.mean(nse)
    # Return mean NSE, and NSE of all locations, respectively
    return nse_mean, nse[:, 0]


def calc_kge(obs: np.array, sim: np.array):
    mean_obs = np.mean(obs, axis=0)
    mean_sim = np.mean(sim, axis=0)

    std_obs = np.std(obs, axis=0)
    std_sim = np.std(sim, axis=0)

    beta = mean_sim / mean_obs
    alpha = std_sim / std_obs
    numerator = np.mean(((obs - mean_obs) * (sim - mean_sim)), axis=0)
    denominator = std_obs * std_sim
    gamma = numerator / denominator
    kge = 1 - np.sqrt((beta - 1) ** 2 + (alpha - 1) ** 2 + (gamma - 1) ** 2)

    kge_mean = np.mean(kge)
    # Return mean KGE, and KGE of all locations, respectively
    return kge_mean, kge[:, 0]


def calc_tpe(obs: np.array, sim: np.array, alpha):
    sort_index = np.argsort(obs, axis=0)
    obs_sort = np.take_along_axis(obs, sort_index, axis=0)
    sim_sort = np.take_along_axis(sim, sort_index, axis=0)
    top = int(obs.shape[0] * alpha)
    obs_t = obs_sort[-top:, :]
    sim_t = sim_sort[-top:, :]
    numerator = np.sum(np.abs(sim_t - obs_t), axis=0)
    denominator = np.sum(obs_t, axis=0)
    tpe = numerator / denominator

    tpe_mean = np.mean(tpe)
    # Return mean TPE, and TPE of all locations, respectively
    return tpe_mean, tpe[:, 0]


def calc_bias(obs: np.array, sim: np.array):
    numerator = np.sum(sim - obs, axis=0)
    denominator = np.sum(obs, axis=0)
    bias = numerator / denominator

    bias_mean = np.mean(bias)
    # Return mean bias, and bias of all locations, respectively
    return bias_mean, bias[:, 0]


def calc_mse(obs: np.array, sim: np.array):
    mse = np.mean((obs - sim) ** 2, axis=0)

    mse_mean = np.mean(mse)
    # Return mean MSE, and MSE of all locations, respectively
    return mse_mean, mse[:, 0]


def calc_rmse(obs: np.array, sim: np.array):
    mse = np.mean((obs - sim) ** 2, axis=0)
    rmse = np.sqrt(mse)

    rmse_mean = np.mean(rmse)
    # Return mean RMSE, and RMSE of all locations, respectively
    return rmse_mean, rmse[:, 0]


def calc_nrmse(obs: np.array, sim: np.array):
    mse = np.mean((obs - sim) ** 2, axis=0)
    rmse = np.sqrt(mse)
    obs_mean = np.mean(obs, axis=0)
    nrmse = rmse / obs_mean

    nrmse_mean = np.mean(nrmse)
    # Return mean NRMSE, and NRMSE of all locations, respectively
    return nrmse_mean, nrmse[:, 0]


def calc_nse_torch(obs, sim):
    with torch.no_grad():
        denominator = torch.sum((obs - torch.mean(obs, dim=0)) ** 2, dim=0)
        numerator = torch.sum((sim - obs) ** 2, dim=0)
        nse = torch.tensor(1).to(sim.device) - numerator / denominator

        nse_mean = torch.mean(nse)
        # Return mean NSE, and NSE of all locations, respectively
        return nse_mean, nse[:, 0]


# Here we add some further functions to calculate metrics

# We add an extended version of the Kling-Gupta Efficiency (KGE) metric
def calc_kge_ext(obs: np.array, sim: np.array) -> np.array: #-> dict:
    #r = np.corrcoef(obs, sim)[0, 1]
    r = np.array([np.corrcoef(obs[:, i], sim[:, i])[0, 1] for i in range(sim.shape[1])])
    beta = np.mean(sim, axis=0) / np.mean(obs, axis=0)
    #alpha2009 = np.std(sim, axis=0) / np.std(obs, axis=0)
    alpha2012 = (np.std(sim, axis=0) / np.mean(sim, axis=0)) / (np.std(obs, axis=0) / np.mean(obs, axis=0))
    
    #kge2009 = 1 - np.sqrt((r - 1) ** 2 + (beta - 1) ** 2 + (alpha2009 - 1) ** 2)
    kge2012 = 1 - np.sqrt((r - 1) ** 2 + (beta - 1) ** 2 + (alpha2012 - 1) ** 2)
    
    #return {'kge2009': kge2009, 
    #        'kge2012': kge2012, 
    #        'r': r, 
    #        'beta': beta, 
    #        'alpha2009': alpha2009, 
    #        'alpha2012': alpha2012}
    
    kge2012_mean = np.mean(kge2012)
    # Return mean KGE, and KGE of all locations, respectively
    return kge2012_mean, kge2012[:, 0]

def calc_kge_ext_comp(obs: np.array, sim: np.array) -> np.array: #-> dict:?
    #r = np.corrcoef(obs, sim)[0, 1]
    r = np.array([np.corrcoef(obs[:, i], sim[:, i])[0, 1] for i in range(sim.shape[1])])
    beta = np.mean(sim, axis=0) / np.mean(obs, axis=0)
    #alpha2009 = np.std(sim, axis=0) / np.std(obs, axis=0)
    alpha2012 = (np.std(sim, axis=0) / np.mean(sim, axis=0)) / (np.std(obs, axis=0) / np.mean(obs, axis=0))
    
    #return {'kge2009': kge2009, 
    #        'kge2012': kge2012, 
    #        'r': r, 
    #        'beta': beta, 
    #        'alpha2009': alpha2009, 
    #        'alpha2012': alpha2012}
    
    r_mean = np.mean(r)
    beta_mean = np.mean(beta)
    alpha2012_mean = np.mean(alpha2012 )
    # Return mean KGE, and KGE of all locations, respectively
    return r_mean, r[:, 0], beta_mean, beta[:, 0], alpha2012_mean, alpha2012 [:, 0]

# We add the non-parametric Kling-Gupta Efficiency (KGEnp) metric
def calc_kgenp(obs: np.array, sim: np.array) -> tuple: #-> dict:

    # Instead of importing scipy, we define the rankdata and calc_spearmanr functions here
    def rankdata(a, axis=0):
        # Rank the data along the specified axis
        ranks = np.argsort(np.argsort(a, axis=axis), axis=axis) + 1
        return ranks

    def calc_spearmanr(x, y, axis=0):
        # Rank both variables along the specified axis
        rx = rankdata(x, axis=axis)
        ry = rankdata(y, axis=axis)

        # Calculate the Pearson correlation coefficient on the ranks
        mean_rx = np.mean(rx, axis=axis)
        mean_ry = np.mean(ry, axis=axis)

        cov = np.sum((rx - mean_rx) * (ry - mean_ry), axis=axis)
        std_rx = np.sqrt(np.sum((rx - mean_rx) ** 2, axis=axis))
        std_ry = np.sqrt(np.sum((ry - mean_ry) ** 2, axis=axis))

        return cov / (std_rx * std_ry)
    
    # Calculate normalized flow duration curves
    fdc_sim = np.sort(sim / (np.mean(sim, axis=0) * len(sim)), axis=0)
    fdc_obs = np.sort(obs / (np.mean(obs, axis=0) * len(obs)), axis=0)

    # Calculate r component using the manually computed Spearman correlation for each column (location)
    kgenp_r = calc_spearmanr(sim, obs, axis=0)

    # Calculate alpha component
    kgenp_alpha = 1 - 0.5 * np.sum(np.abs(fdc_sim - fdc_obs), axis=0)


    # Bias component
    kge_beta = np.mean(sim, axis=0) / np.mean(obs, axis=0)

    # Calculate non-parametric KGE
    kgenp = 1 - np.sqrt((kgenp_r - 1) ** 2 + (kge_beta - 1) ** 2 + (kgenp_alpha - 1) ** 2)

    # Calculate the mean KGE across all locations
    kgenp_mean = np.mean(kgenp)

    ## Return KGENP and individual components
    #return {
    #    'kgenp': kgenp,
    #    'kgenp_r': kgenp_r,
    #    'kgenp_alpha': kgenp_alpha,
    #    'kge_beta': kge_beta
    #}

    # Return mean KGENP, and KGENP of all locations, respectively
    return kgenp_mean, kgenp[:,0]

# We include metrics related to the flow duration curve FDC
# here calculate the FDC Bias for different flow regimes
# the quantiles could be set differently (e.g. 0.1 and 0.9 instead of 0.2 and 0.8), depending on the needs/taste
# two varibles could/should be added to the function to set/change the quantiles more easily
def calc_fdc(obs: np.array, sim: np.array) -> np.array: #-> dict:

    quant = np.linspace(0, 1, 1001)
    
    # Sort observations and simulations along the time axis (rows)
    #sort_index = np.argsort(obs, axis=0)
    #obs_sort = np.take_along_axis(obs, sort_index, axis=0)
    #sim_sort = np.take_along_axis(sim, sort_index, axis=0)
    
    # Compute flow duration curves by quantiles
    #fdc_obs = np.quantile(obs_sort, quant, axis=0)
    #fdc_sim = np.quantile(sim_sort, quant, axis=0)
    fdc_obs = np.quantile(obs, quant, axis=0)
    fdc_sim = np.quantile(sim, quant, axis=0)
    
    # Retrieve Q20 and Q80 for each column
    q20_obs = fdc_obs[200, :]  # Index corresponding to quantile 0.2
    q80_obs = fdc_obs[800, :]  # Index corresponding to quantile 0.8
    q20_sim = fdc_sim[200, :]
    q80_sim = fdc_sim[800, :]
    
    # Calculate slope of FDC (for each column)
    sfdc_obs = (q80_obs - q20_obs) / (0.8 - 0.2)
    sfdc_sim = (q80_sim - q20_sim) / (0.8 - 0.2)
    
    # Calculate bias in the slope of the middle FDC (for each column)
    biasfms = (sfdc_sim - sfdc_obs) / sfdc_obs
    
    # FDC Biases for different flow regimes (for each column)
    biasfdc_low = np.mean(fdc_sim[quant > 0.8, :], axis=0) / np.mean(fdc_obs[quant > 0.8, :], axis=0) - 1
    biasfdc_mid = np.mean(fdc_sim[(quant > 0.2) & (quant <= 0.8), :], axis=0) / np.mean(fdc_obs[(quant > 0.2) & (quant <= 0.8), :], axis=0) - 1
    biasfdc_high = np.mean(fdc_sim[quant <= 0.2, :], axis=0) / np.mean(fdc_obs[quant <= 0.2, :], axis=0) - 1
    
    # Calculate mean values across all columns
    biasfms_mean = np.mean(biasfms)
    
    #return {
    #    'biasfms': biasfms,
    #    'biasfdc_low': biasfdc_low,
    #    'biasfdc_mid': biasfdc_mid,
    #    'biasfdc_high': biasfdc_high,
    #}

    biasfms_mean = np.mean(biasfms)
    # Return mean bias in the slope of the middle FDC BIASFMS, and BIASFMS of all locations, respectively
    return biasfms_mean, biasfms


# We could combine the metrics in a single function?
# Let's call if GOF (Goodness of Fit)
def calc_GOF(obs: np.array, sim: np.array) -> dict:
    nse = calc_nse(obs, sim)
    kge = calc_kge(obs, sim)
    bias = calc_bias(obs, sim)
    rmse = calc_rmse(obs, sim)
    fdc = calc_fdc(obs, sim)
    
    return {
        'nse': nse[0],
        'kge2009': kge['kge2009'],
        'kge2012': kge['kge2012'],
        'pbias': bias,
        'rmse': rmse[0],
        'biasfms': fdc['biasfms'],
        'biasfdc_low': fdc['biasfdc_low'],
        'biasfdc_mid': fdc['biasfdc_mid'],
        'biasfdc_high': fdc['biasfdc_high'],
        'r': kge['r'],
        'beta': kge['beta'],
        'alpha2009': kge['alpha2009'],
        'alpha2012': kge['alpha2012']
    }
