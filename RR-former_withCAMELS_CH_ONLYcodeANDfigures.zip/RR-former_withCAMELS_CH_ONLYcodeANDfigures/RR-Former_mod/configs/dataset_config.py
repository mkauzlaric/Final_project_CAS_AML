import pandas as pd
from pathlib import Path


class DatasetConfig:
    # TODO: set dataset configurations
    camels_root = Path("S:\\CAMELS-CH\\CAMELS-CH\\camels_ch")  # your CAMELS dataset root
    forcing_type = "daymet"  
    basin_mark = "193"  
    basins_file = f"data/{basin_mark}basins_list.txt"
    global_basins_list = pd.read_csv(basins_file, header=None, dtype=str)[0].values.tolist()
    #You can comment out the following lines if you didn't do kfold cross-validation
    #and/or if you want things to be run on all basins
    test_basin_mark = "42"
    fold = "fold3" #Note, this is the fold number, you can change it to fold1, fold2, fold3, fold4
    test_basins_file = f"data/{fold}_{test_basin_mark}testbasins_list.txt"
    test_basins_list = pd.read_csv(test_basins_file, header=None, dtype=str)[0].values.tolist()

    # TODO: set training, validation and testing dates
    train_start = pd.to_datetime("1980-10-01", format="%Y-%m-%d")
    train_end = pd.to_datetime("1995-09-30", format="%Y-%m-%d")
    val_start = pd.to_datetime("1995-10-01", format="%Y-%m-%d")
    val_end = pd.to_datetime("2000-09-30", format="%Y-%m-%d")
    test_start = pd.to_datetime("2000-10-01", format="%Y-%m-%d")
    test_end = pd.to_datetime("2014-09-30", format="%Y-%m-%d")

    # TODO: K-Fold Cross-Validation settings
    kfold_basin_split = False  # whether to perform kfold basin split
    kfold_type = "strat"  # whether to perform stratified kfold (strat) or not (regular)
    classes_file = f"data/{basin_mark}classes_list.txt"
    num_folds = 5  # Number of folds for kfold cross-validation
    
    if kfold_basin_split:
        # Construct dataset_info for kfold basin split scenario
        if kfold_type == "strat":
            # Check if class list file exists and read it if present
            classes_file_path = Path(classes_file)
            if classes_file_path.exists():
                global_classes_list = pd.read_csv(classes_file_path, header=None, dtype=str)[0].values.tolist()
            else:
                raise FileNotFoundError(f"Class list file {classes_file} not found. Required for stratified k-fold.")
            kfold_type = "strat"
        else:
            kfold_type = "regular"
        
        dataset_info = f"{forcing_type}{basin_mark}#kfold_{kfold_type}_{num_folds}folds_{train_start.year}~{train_end.year}#{val_start.year}~{val_end.year}#{test_start.year}~{test_end.year}"
    else:
        # Original dataset_info format
        dataset_info = f"{forcing_type}{basin_mark}_{train_start.year}~{train_end.year}#{val_start.year}~{val_end.year}#{test_start.year}~{test_end.year}"