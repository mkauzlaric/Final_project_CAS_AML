import torch.nn as nn
import importlib

from ..project_config import ProjectConfig
from ..dataset_config import DatasetConfig
from ..data_shape_config import DataShapeConfig
from utils import nseloss


class PretrainLearningConfig:
    loss_type = "MSE"  # TODO: loss function type, chose in ["NSELoss" ,"MSE"]
    loss_functions = {"MSE": nn.MSELoss(), "NSELoss": nseloss.NSELoss()}
    loss_func = loss_functions[loss_type]

    scale_factor = 1  # TODO: usually, the bigger is the batch_size, the larger will have to be the learning_rate.
    n_epochs = 100  # TODO
    batch_size = 128 // scale_factor  # TODO
    learning_rate = 0.0001 / scale_factor  # TODO
    weight_dr = 0.01  # TODO #we add this
    scheduler_type = "warm_up" # "type" chose in [none, warm_up, cos_anneal, exp_decay]  # TODO

    if scheduler_type == "warm_up":
        warmup_frac = 0.25  # TODO #we add this
        scheduler_paras = {"scheduler_type": "warm_up", #f"warmup_{warmup_frac}"
                        "warm_up_epochs": n_epochs * warmup_frac, 
                        "decay_rate": 0.99}
    elif scheduler_type == "none":
        scheduler_paras = {"scheduler_type": "none"}
    elif scheduler_type == "exp_decay":
        scheduler_paras = {"scheduler_type": "exp_decay", 
                        "decay_epoch": n_epochs * 0.5, 
                        "decay_rate": 0.99}
    elif scheduler_type == "cos_anneal":
        scheduler_paras = {"scheduler_type": "cos_anneal",
                            "cos_anneal_t_max": 32}

    #if type == "warmup":
    #    learning_config_info = f"{loss_type}_n{n_epochs}_bs{batch_size}_lr{learning_rate}_wd{weight_dr}_wup{warmup_frac}_{scheduler_paras['scheduler_type']}"
    #else:
    #    learning_config_info = f"{loss_type}_n{n_epochs}_bs{batch_size}_lr{learning_rate}_wd{weight_dr}_{scheduler_paras['scheduler_type']}"

    #learning_config_info = f"{loss_type}_n{n_epochs}_bs{batch_size}_lr{learning_rate}_{scheduler_paras['scheduler_type']}"
    learning_config_info = f"{loss_type}_n{n_epochs}_bs{batch_size}_lr{learning_rate}_wd{weight_dr}_{scheduler_paras['scheduler_type']}"

class PretrainConfig(PretrainLearningConfig):
    seed = 12  # # TODO None => random seed; otherwise pick a number
    # Define model to use
    used_model = "LSTMMSVS2S"  # TODO (Transformer,LSTMMSVS2S,LSTMS2S)

    used_model_config = importlib.import_module(f"configs.model_config.{used_model}_config")
    used_ModelConfig = getattr(used_model_config, f"{used_model}Config")
    decode_mode = used_ModelConfig.decode_mode
    model_info = used_ModelConfig.model_info

    pre_train_id = f"{DatasetConfig.forcing_type}{DatasetConfig.basin_mark}@{DataShapeConfig.data_shape_info}" \
                   f"@{DatasetConfig.train_start.date()}~{DatasetConfig.train_end.date()}"
    pre_val_id = f"{DatasetConfig.forcing_type}{DatasetConfig.basin_mark}@{DataShapeConfig.data_shape_info}" \
                 f"@{DatasetConfig.val_start.date()}~{DatasetConfig.val_end.date()}"
    pre_test_id = f"{DatasetConfig.forcing_type}{DatasetConfig.basin_mark}@{DataShapeConfig.data_shape_info}" \
                  f"@{DatasetConfig.test_start.date()}~{DatasetConfig.test_end.date()}"
    
    final_train_data_path = ProjectConfig.final_data_root / f"{pre_train_id}_serialized_train.pkl"
    final_val_data_path = ProjectConfig.final_data_root / f"{pre_val_id}_serialized_val.pkl"
    final_test_data_path = ProjectConfig.final_data_root / f"{pre_test_id}_serialized_test.pkl"
    
    pre_train_config = {
        "camels_root": DatasetConfig.camels_root,
        "basins_list": DatasetConfig.global_basins_list,
        "forcing_type": DatasetConfig.forcing_type,
        "start_date": DatasetConfig.train_start,
        "end_date": DatasetConfig.train_end,
        "final_data_path": final_train_data_path
    }

    pre_val_config = {
        "camels_root": DatasetConfig.camels_root,
        "basins_list": DatasetConfig.global_basins_list,
        "forcing_type": DatasetConfig.forcing_type,
        "start_date": DatasetConfig.val_start,
        "end_date": DatasetConfig.val_end,
        "final_data_path": final_val_data_path
    }

    pre_test_config = {
        "camels_root": DatasetConfig.camels_root,
        "basins_list": DatasetConfig.global_basins_list,
        "forcing_type": DatasetConfig.forcing_type,
        "start_date": DatasetConfig.test_start,
        "end_date": DatasetConfig.test_end,
        "final_data_path": final_test_data_path
    }

    #@staticmethod
    #def generate_fold_config(fold, basins):
    #    # Generate and return the configuration for the given fold
    #    config = {
    #        'train': {
    #            'path': f'path/to/train_config_fold_{fold}.pkl',
    #            'basins': basins['train']
    #        },
    #        'val': {
    #            'path': f'path/to/val_config_fold_{fold}.pkl',
    #            'basins': basins['val']
    #        },
    #        'test': {
    #            'path': f'path/to/test_config_fold_{fold}.pkl',
    #            'basins': basins['test']
    #        }
    #    }
    #    return config

    #@staticmethod
    #def save_fold_config(fold, config):
    #    with open(f'path/to/config_fold_{fold}.pkl', 'wb') as f:
    #        pickle.dump(config, f)

    #@staticmethod
    #def load_fold_config(fold):
    #    with open(f'path/to/config_fold_{fold}.pkl', 'rb') as f:
    #        return pickle.load(f)

    saving_message = f"{model_info}@{DatasetConfig.dataset_info}@{DataShapeConfig.data_shape_info}" \
                     f"@{PretrainLearningConfig.learning_config_info}@seed{seed}"

    saving_root = ProjectConfig.run_root / saving_message
