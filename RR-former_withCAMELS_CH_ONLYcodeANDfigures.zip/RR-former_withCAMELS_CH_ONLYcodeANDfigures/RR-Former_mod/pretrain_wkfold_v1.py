import torch
import os
import numpy as np
import json
import importlib
from shutil import copytree
from torch.utils.data import DataLoader
from sklearn.model_selection import KFold, StratifiedKFold

from configs.project_config import ProjectConfig
from configs.data_shape_config import DataShapeConfig
from configs.dataset_config import DatasetConfig
from configs.run_config.pretrain_config import PretrainConfig
from utils.tools import SeedMethods
from utils.lr_strategies import SchedulerFactory
from utils.train_full import train_full
from data.dataset import DatasetFactory

project_root = ProjectConfig.project_root
device = ProjectConfig.device
num_workers = ProjectConfig.num_workers

past_len = DataShapeConfig.past_len
pred_len = DataShapeConfig.pred_len
src_len = DataShapeConfig.src_len
tgt_len = DataShapeConfig.tgt_len
src_size = DataShapeConfig.src_size
tgt_size = DataShapeConfig.tgt_size
use_future_fea = DataShapeConfig.use_future_fea
use_static = DataShapeConfig.use_static

kfold_basin_split = DatasetConfig.kfold_basin_split
num_folds = DatasetConfig.num_folds
kfold_type = DatasetConfig.kfold_type

used_model = PretrainConfig.used_model
decode_mode = PretrainConfig.decode_mode
pre_train_config = PretrainConfig.pre_train_config
pre_val_config = PretrainConfig.pre_val_config
pre_test_config = PretrainConfig.pre_test_config
loss_func = PretrainConfig.loss_func
n_epochs = PretrainConfig.n_epochs
batch_size = PretrainConfig.batch_size
learning_rate = PretrainConfig.learning_rate
scheduler_paras = PretrainConfig.scheduler_paras
weight_dr = PretrainConfig.weight_dr # we add this

seed = PretrainConfig.seed
saving_message = PretrainConfig.saving_message
saving_root = PretrainConfig.saving_root

if __name__ == '__main__':
    print("pid:", os.getpid())
    SeedMethods.seed_torch(seed=seed)
    saving_root.mkdir(exist_ok=True, parents=True)
    print(saving_root)
    # Saving config files
    configs_path = project_root / "configs"
    configs_saving = saving_root / "configs"
    if configs_saving.exists():
        raise RuntimeError("config files already exists!")
    copytree(configs_path, configs_saving)

    # Define model type
    models = importlib.import_module("models")
    Model = getattr(models, used_model)

    # Get list of basins
    all_basins = DatasetConfig.global_basins_list

    if kfold_basin_split:
        # Perform k-fold splitting
        if kfold_type == "strat":
            # Get list of class labels
            all_classes = DatasetConfig.global_classes_list
            if all_classes is not None:
                skf = StratifiedKFold(n_splits=num_folds, shuffle=True, random_state=seed)
                basin_splits = list(skf.split(all_basins, all_classes))
            else:
                raise FileNotFoundError(f"Class list file is somehow missing, but required for stratified k-fold.")
        else:
            kf = KFold(n_splits=num_folds, shuffle=True, random_state=seed)
            basin_splits = list(kf.split(all_basins))

        for fold_idx, (train_idx, val_idx) in enumerate(basin_splits):
            # Initialize sets for fold indices
            folds = set(range(num_folds))
            val_folds = {fold_idx % num_folds}
            test_folds = {(fold_idx + 1) % num_folds}
            train_folds = folds - val_folds - test_folds

            # Convert basin indices to a set for easier manipulation
            basin_indices_set = set(range(len(all_basins)))

            # Assign basins to train, valid, and test based on fold assignments
            train_basins = [all_basins[i] for i in basin_indices_set if i % num_folds in train_folds]
            val_basins = [all_basins[i] for i in basin_indices_set if i % num_folds in val_folds]
            test_basins = [all_basins[i] for i in basin_indices_set if i % num_folds in test_folds]

            # Dataset
            DS = DatasetFactory.get_dataset_type(use_future_fea, use_static)

            # Training data
            ds_train = DS.get_instance(past_len, pred_len, "train", specific_cfg=pre_train_config, basins_list=train_basins)
            train_loader = DataLoader(ds_train, batch_size=batch_size, num_workers=num_workers, shuffle=True)

            # Compute means and stds for the current fold
            train_x_mean, train_y_mean = ds_train.get_means()
            train_x_std, train_y_std = ds_train.get_stds()
            y_stds_dict = ds_train.y_stds_dict

            # Saving training mean and training std for the current fold
            train_means = np.concatenate((train_x_mean, train_y_mean), axis=0)
            train_stds = np.concatenate((train_x_std, train_y_std), axis=0)
            np.savetxt(saving_root / f"train_means_fold_{fold_idx}.csv", train_means)
            np.savetxt(saving_root / f"train_stds_fold_{fold_idx}.csv", train_stds)
            with open(saving_root / f"y_stds_dict_fold_{fold_idx}.json", "wt") as f:
                json.dump(y_stds_dict, f)

            # Validation data (needs training mean and training std for the current fold)
            ds_val = DS.get_instance(past_len, pred_len, "val", specific_cfg=pre_val_config,
                                 x_mean=train_x_mean, y_mean=train_y_mean, x_std=train_x_std, y_std=train_y_std,
                                 y_stds_dict=y_stds_dict, basins_list=val_basins)
            val_loader = DataLoader(ds_val, batch_size=batch_size, num_workers=num_workers, shuffle=False)

            # Testing data (needs training mean and training std)
            ds_test = DS.get_instance(past_len, pred_len, "test", specific_cfg=pre_test_config,
                                 x_mean=train_x_mean, y_mean=train_y_mean, x_std=train_x_std, y_std=train_y_std,
                                 y_stds_dict=y_stds_dict, basins_list=test_basins)
            test_loader = DataLoader(ds_test, batch_size=batch_size, num_workers=num_workers, shuffle=False)

            # Model, Optimizer, Scheduler, Loss for the current fold
            model = Model().to(device)
            #optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate) # we change this
            optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay= weight_dr)
            scheduler = SchedulerFactory.get_scheduler(optimizer, **scheduler_paras)
            loss_func = loss_func.to(device)

            # Training and Validation for the current fold
            train_full(model, decode_mode, train_loader, val_loader, optimizer, scheduler, loss_func, n_epochs, device,
                   saving_root / f"fold_{fold_idx}")

            # Save the model for the current fold
            torch.save(model.state_dict(), saving_root / f"model_fold_{fold_idx}.pt")
    else:
        # Dataset
        DS = DatasetFactory.get_dataset_type(use_future_fea, use_static)

        # Training data
        ds_train = DS.get_instance(past_len, pred_len, "train", specific_cfg=pre_train_config)
        train_loader = DataLoader(ds_train, batch_size=batch_size, num_workers=num_workers, shuffle=True)

        # We use the feature means/stds of the training data for normalization in val and test stage
        train_x_mean, train_y_mean = ds_train.get_means()
        train_x_std, train_y_std = ds_train.get_stds()
        y_stds_dict = ds_train.y_stds_dict
        # Saving training mean and training std
        train_means = np.concatenate((train_x_mean, train_y_mean), axis=0)
        train_stds = np.concatenate((train_x_std, train_y_std), axis=0)
        np.savetxt(saving_root / "train_means.csv", train_means)
        np.savetxt(saving_root / "train_stds.csv", train_stds)
        with open(saving_root / "y_stds_dict.json", "wt") as f:
            json.dump(y_stds_dict, f)

        # Validation data (needs training mean and training std)
        ds_val = DS.get_instance(past_len, pred_len, "val", specific_cfg=pre_val_config,
                                 x_mean=train_x_mean, y_mean=train_y_mean, x_std=train_x_std, y_std=train_y_std,
                                 y_stds_dict=y_stds_dict)
        val_loader = DataLoader(ds_val, batch_size=batch_size, num_workers=num_workers, shuffle=False)

        # Testing data (needs training mean and training std)
        ds_test = DS.get_instance(past_len, pred_len, "test", specific_cfg=pre_test_config,
                                  x_mean=train_x_mean, y_mean=train_y_mean, x_std=train_x_std, y_std=train_y_std,
                                  y_stds_dict=y_stds_dict)
        test_loader = DataLoader(ds_test, batch_size=batch_size, num_workers=num_workers, shuffle=False)

        # Model, Optimizer, Scheduler, Loss
        model = Model().to(device)
        optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
        scheduler = SchedulerFactory.get_scheduler(optimizer, **scheduler_paras)
        loss_func = loss_func.to(device)

        # Training and Validation
        train_full(model, decode_mode, train_loader, val_loader, optimizer, scheduler, loss_func, n_epochs, device,
                   saving_root)
        
        # Save the model for the current fold
        torch.save(model.state_dict(), saving_root / f"model_global.pt")