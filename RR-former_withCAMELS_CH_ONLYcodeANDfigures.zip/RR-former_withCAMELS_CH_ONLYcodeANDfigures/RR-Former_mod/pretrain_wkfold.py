import uuid
#import hashlib
import torch
import os
import numpy as np
import json
import importlib
from pathlib import Path
import shutil
from shutil import copytree
from torch.utils.data import DataLoader
from sklearn.model_selection import KFold, StratifiedKFold

from configs.project_config import ProjectConfig
from configs.data_shape_config import DataShapeConfig
from configs.dataset_config import DatasetConfig
from configs.run_config.pretrain_config import PretrainConfig
from configs.run_config.pretrain_config import PretrainLearningConfig  # we add this
from utils.tools import SeedMethods
from utils.lr_strategies import SchedulerFactory
from utils.train_full import train_full
from data.dataset import DatasetFactory

project_root = ProjectConfig.project_root
device = ProjectConfig.device
num_workers = ProjectConfig.num_workers

past_len = DataShapeConfig.past_len
pred_len = DataShapeConfig.pred_len
src_len = DataShapeConfig.src_len
tgt_len = DataShapeConfig.tgt_len
src_size = DataShapeConfig.src_size
tgt_size = DataShapeConfig.tgt_size
use_future_fea = DataShapeConfig.use_future_fea
use_static = DataShapeConfig.use_static

kfold_basin_split = DatasetConfig.kfold_basin_split
num_folds = DatasetConfig.num_folds
kfold_type = DatasetConfig.kfold_type

used_model = PretrainConfig.used_model
decode_mode = PretrainConfig.decode_mode
#dropout = PretrainConfig.dropout # we add this
pre_train_config = PretrainConfig.pre_train_config
pre_val_config = PretrainConfig.pre_val_config
pre_test_config = PretrainConfig.pre_test_config
loss_func = PretrainConfig.loss_func
n_epochs = PretrainConfig.n_epochs
if PretrainLearningConfig.scheduler_type == "warm_up":
    warmup_frac = PretrainConfig.warmup_frac
batch_size = PretrainConfig.batch_size
learning_rate = PretrainConfig.learning_rate
scheduler_paras = PretrainConfig.scheduler_paras
weight_dr = PretrainConfig.weight_dr # we add this

seed = PretrainConfig.seed
saving_message = PretrainConfig.saving_message
saving_root = PretrainConfig.saving_root

model_info = PretrainConfig.model_info # we add this

def train_kfold(fold_idx, learning_rate, batch_size, weight_dr, loss_func,
                pre_train_config, pre_val_config, pre_test_config,
                past_len, pred_len, num_workers,
                saving_root_fold,
                global_y_stds_dict):

    #print("Get training data in the optimization loop in fold0")
    # Training data
    ds_train = DS.get_instance(past_len, pred_len, "train", specific_cfg=pre_train_config)
    #print("Load training data in the optimization loop in fold0")
    train_loader = DataLoader(ds_train, batch_size=batch_size, num_workers=num_workers, shuffle=True)
    #print("Compute training means and stds in the optimization loop in fold0")
    # Compute means and stds for the current fold
    train_x_mean, train_y_mean = ds_train.get_means()
    train_x_std, train_y_std = ds_train.get_stds()
    #print("Make training y_stds_dict  in the optimization loop in fold0")
    y_stds_dict = ds_train.y_stds_dict

    # Saving training mean and training std for the current fold
    train_means = np.concatenate((train_x_mean, train_y_mean), axis=0)
    train_stds = np.concatenate((train_x_std, train_y_std), axis=0)
    np.savetxt(saving_root_fold / f"train_means_fold_{fold_idx}.csv", train_means)
    np.savetxt(saving_root_fold/ f"train_stds_fold_{fold_idx}.csv", train_stds)
    with open(saving_root_fold / f"y_stds_dict_fold_{fold_idx}.json", "wt") as f:
                json.dump(y_stds_dict, f)

    # Ensure global_y_stds_dict is a dictionary before you run this part of the code
    if not isinstance(global_y_stds_dict, dict):
        raise TypeError("global_y_stds_dict should be a dictionary")
    
    #print("Compute validation means and stds in the optimization loop in fold0")
    # Validation data (needs training mean and training std for the current fold)
    
    # Extract validation basins from pre_val_config
    val_basins = pre_val_config['basins_list']
    #print(f"val_basins: {val_basins}")
    #print(f"len: {len(val_basins)}")

    # Initialize empty lists and dictionaries for validation statistics
    val_y_stds_dict = {}

    # Extract statistics for validation basins
    for basin in val_basins:
        if basin not in global_y_stds_dict:
            raise KeyError(f"Basin {basin} not found in global_y_stds_dict")
    
        # Find the index of the basin
        #basin_index = list(global_y_stds_dict.keys()).index(basin)
        #print(f"basin index is: {basin_index}")
        # Use the index to access global_x_mean
        val_y_stds_dict[basin] = global_y_stds_dict[basin]

    # Validation data      
    ds_val = DS.get_instance(past_len, pred_len, "val", specific_cfg=pre_val_config,
                        x_mean=train_x_mean, y_mean=train_y_mean, x_std=train_x_std, y_std=train_y_std,
                        y_stds_dict=val_y_stds_dict)
    #print("Load validation data in the optimization loop in fold0")
    val_loader = DataLoader(ds_val, batch_size=batch_size, num_workers=num_workers, shuffle=False)

    #print("Compute testing means and stds in the optimization loop in fold0")
    # Testing data (needs training mean and training std)
    # Extract testing basins from pre_test_config
    test_basins = pre_test_config['basins_list']
    #print(f"test_basins: {test_basins}")
    #print(f"len: {len(test_basins)}")

    # Initialize empty lists and dictionaries for validation statistics
    test_y_stds_dict = {}

    # Extract statistics for validation basins
    for basin in test_basins:
        if basin not in global_y_stds_dict:
            raise KeyError(f"Basin {basin} not found in global_y_stds_dict")
    
        # Find the index of the basin
        #basin_index = list(global_y_stds_dict.keys()).index(basin)
        #print(f"basin index is: {basin_index}")
        # Use the index to access global_x_mean
        test_y_stds_dict[basin] = global_y_stds_dict[basin]

    # Testing data (needs training mean and training std)
    ds_test = DS.get_instance(past_len, pred_len, "test", specific_cfg=pre_test_config,
                        x_mean=train_x_mean, y_mean=train_y_mean, x_std=train_x_std, y_std=train_y_std,
                        y_stds_dict=test_y_stds_dict)
    #print("Load testing data in the optimization loop in fold0")
    test_loader = DataLoader(ds_test, batch_size=batch_size, num_workers=num_workers, shuffle=False)

    # Model, Optimizer, Scheduler, Loss for the current fold
    model = Model().to(device)
    #optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate) # we change this
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay= weight_dr)
    scheduler = SchedulerFactory.get_scheduler(optimizer, **scheduler_paras)
    loss_func = loss_func.to(device)

    # Training and Validation for the current fold
    train_full(model, decode_mode, train_loader, val_loader, optimizer, scheduler, loss_func, n_epochs, device,
                saving_root_fold)

    # Save the model for the current fold
    torch.save(model.state_dict(), saving_root_fold / f"model_training_fold_{fold_idx}.pt")


if __name__ == '__main__': # Note: this is a conditional block that determines whether a script is being run directly or imported as a module.
    # Code organization: It helps to separate the main program logic from reusable functions and classes.
    # Testing: It allows you to include test cases within the same script without running them when the module is imported.
    # Reusability: It ensures that the script can be imported as a module without unintended side effects.

    print("pid:", os.getpid())
    SeedMethods.seed_torch(seed=seed)
    #saving_root.mkdir(exist_ok=True, parents=True)
    #print(saving_root)
    # Saving config files
    #configs_path = project_root / "configs"
    #configs_saving = saving_root / "configs"
    #if configs_saving.exists():
    #    raise RuntimeError("config files already exists!")
    #copytree(configs_path, configs_saving)

    # Define model type
    models = importlib.import_module("models")
    Model = getattr(models, used_model)

    # Get list of basins
    all_basins = DatasetConfig.global_basins_list
 
    print("Starting with the kfold splitting")
    if kfold_basin_split:

        # Define ignore patterns for copying configs
        def ignore_files_and_dirs(src, names):
            ignore_list = []
            for name in names:
                if name == '__pycache__' or name.endswith('.pyc') or name.endswith('.pyo') or name.endswith('~'):
                    ignore_list.append(name)
            return set(ignore_list)
        
        def copy_tree_with_ignore(src, dst, ignore=None):
            try:
                shutil.copytree(src, dst, ignore=ignore)
            except shutil.Error as e:
                print(f"Error occurred while copying: {e}")
            except OSError as e:
                print(f"OS error occurred: {e}")

        # Generate saving message and root for each fold
        saving_message = f"{model_info}@{DatasetConfig.dataset_info}@{DataShapeConfig.data_shape_info}" \
                         f"@{PretrainLearningConfig.learning_config_info}@seed{seed}"
        saving_root = ProjectConfig.run_root / saving_message

        # Ensure the saving_root directory exists
        saving_root.mkdir(exist_ok=True, parents=True)
        print(saving_root)

        # Saving config files
        configs_path = project_root / "configs"
        configs_saving = saving_root / "configs"
        if configs_saving.exists():
            raise RuntimeError("config files already exists!")
        #copytree(configs_path, configs_saving)
        copy_tree_with_ignore(configs_path, configs_saving, ignore=ignore_files_and_dirs)

        pre_global_id = f"{DatasetConfig.forcing_type}{DatasetConfig.basin_mark}@{DataShapeConfig.data_shape_info}" \
                        f"@{DatasetConfig.train_start.date()}~{DatasetConfig.train_end.date()}"

        pre_global_config = {
            "camels_root": DatasetConfig.camels_root,
            "basins_list": DatasetConfig.global_basins_list,
            "forcing_type": DatasetConfig.forcing_type,
            "start_date": DatasetConfig.train_start,
            "end_date": DatasetConfig.train_end,
            "final_data_path": ProjectConfig.final_data_root / f"{pre_global_id}_serialized_train_global.pkl"
        }
        
        # Dataset
        DS = DatasetFactory.get_dataset_type(use_future_fea, use_static)

        # Calculate global means and stds for the entire dataset
        ds_global = DS.get_instance(past_len, pred_len, "train", specific_cfg=pre_global_config)
        global_x_mean, global_y_mean = ds_global.get_means()
        global_x_std, global_y_std = ds_global.get_stds()
        global_y_stds_dict = ds_global.y_stds_dict

        # Save global statistics
        np.savetxt(saving_root / "global_means.csv", np.concatenate((global_x_mean, global_y_mean), axis=0))
        np.savetxt(saving_root / "global_stds.csv", np.concatenate((global_x_std, global_y_std), axis=0))
        with open(saving_root / "global_y_stds_dict.json", "wt") as f:
            json.dump(global_y_stds_dict, f)
    
        print("Perform k-fold splitting")
        # Perform k-fold splitting
        if kfold_type == "strat":
            # Get list of class labels
            all_classes = DatasetConfig.global_classes_list
            if all_classes is not None:
                outer_skf = StratifiedKFold(n_splits=num_folds, shuffle=True, random_state=seed)
                outer_basin_splits = list(outer_skf.split(all_basins, all_classes))
            else:
                raise FileNotFoundError(f"Class list file is somehow missing, but required for stratified k-fold.")
        else:
            outer_kf = KFold(n_splits=num_folds, shuffle=True, random_state=seed)
            outer_basin_splits = list(outer_kf.split(all_basins))

        print("Start iterating folds")
        for fold_idx, (train_val_idx, test_idx) in enumerate(outer_basin_splits):

            # Generate saving message and root for each fold
            saving_root_fold = saving_root/ f"fold{fold_idx}"

            # Ensure the saving_root directory exists
            saving_root_fold.mkdir(exist_ok=True, parents=True)
            print(saving_root_fold)

            # Convert train_val_idx to a NumPy array for proper indexing
            train_val_idx = np.array(train_val_idx)

            # Split train_val_idx into train and validation sets (num_folds-1 splits for training, 1 split for validation)
            train_val_classes = np.array(all_classes)[train_val_idx]
            inner_skf = StratifiedKFold(n_splits=(num_folds-1), shuffle=True, random_state=seed)
            inner_basin_splits = list(inner_skf.split(np.array(all_basins)[train_val_idx], train_val_classes))

            # Initialize an index to keep track of the current fold in the inner split
            inner_fold_idx = fold_idx % (num_folds-1)

            # Use the current fold for validation
            val_idx = inner_basin_splits[inner_fold_idx][1]

            # Use the remaining folds for training
            inner_train_idx = np.setdiff1d(np.arange(len(train_val_idx)), val_idx)

            # Map the inner indices to the original indices
            train_idx = train_val_idx[inner_train_idx]
            val_idx = train_val_idx[val_idx]

            #print(f"test_idx: {test_idx}")
            #print(f"len: {len(test_idx)}")
            #print(f"train_idx: {train_idx}")
            #print(f"len: {len(train_idx)}")
            #print(f"val_idx: {val_idx}")
            #print(f"len: {len(val_idx)}")

            # Assign basins to train, valid, and test based on fold assignments
            # and derived lists of indices train_idx, val_idx, and test_idx are lists of indices
            train_basins = [all_basins[i] for i in train_idx]
            val_basins = [all_basins[i] for i in val_idx]
            test_basins = [all_basins[i] for i in test_idx]

            #print(f"test_basins: {test_basins}")
            #print(f"len: {len(test_basins)}")
            #print(f"train_basins: {train_basins}")
            #print(f"len: {len(train_basins)}")
            #print(f"val_basins: {val_basins}")
            #print(f"len: {len(val_basins)}")


            # Overwrite configurations for each fold
            pre_train_id = f"{DatasetConfig.forcing_type}{DatasetConfig.basin_mark}@{DataShapeConfig.data_shape_info}" \
                        f"@fold{fold_idx}@{DatasetConfig.train_start.date()}~{DatasetConfig.train_end.date()}"
            pre_val_id = f"{DatasetConfig.forcing_type}{DatasetConfig.basin_mark}@{DataShapeConfig.data_shape_info}" \
                        f"@fold{fold_idx}@{DatasetConfig.val_start.date()}~{DatasetConfig.val_end.date()}"
            pre_test_id = f"{DatasetConfig.forcing_type}{DatasetConfig.basin_mark}@{DataShapeConfig.data_shape_info}" \
                        f"@fold{fold_idx}@{DatasetConfig.test_start.date()}~{DatasetConfig.test_end.date()}"

            final_train_data_path = ProjectConfig.final_data_root / f"{pre_train_id}_serialized_train.pkl"
            final_val_data_path = ProjectConfig.final_data_root / f"{pre_val_id}_serialized_val.pkl"
            final_test_data_path = ProjectConfig.final_data_root / f"{pre_test_id}_serialized_test.pkl"

            pre_train_config = {
                "camels_root": DatasetConfig.camels_root,
                "basins_list": train_basins,
                "forcing_type": DatasetConfig.forcing_type,
                "start_date": DatasetConfig.train_start,
                "end_date": DatasetConfig.train_end,
                "final_data_path": final_train_data_path
            }

            pre_val_config = {
                "camels_root": DatasetConfig.camels_root,
                "basins_list": val_basins,
                "forcing_type": DatasetConfig.forcing_type,
                "start_date": DatasetConfig.val_start,
                "end_date": DatasetConfig.val_end,
                "final_data_path": final_val_data_path
            }

            pre_test_config = {
                "camels_root": DatasetConfig.camels_root,
                "basins_list": test_basins,
                "forcing_type": DatasetConfig.forcing_type,
                "start_date": DatasetConfig.test_start,
                "end_date": DatasetConfig.test_end,
                "final_data_path": final_test_data_path
            }

             # Training and Validation for the current fold
            train_kfold(fold_idx, learning_rate, batch_size, weight_dr, loss_func,
                pre_train_config, pre_val_config, pre_test_config,
                past_len, pred_len, num_workers,
                saving_root_fold,
                global_y_stds_dict)
            
    else:

        # No k-fold splitting

        # Ensure the saving_root directory exists
        saving_root.mkdir(exist_ok=True, parents=True)
        print(saving_root)

        # Saving config files
        configs_path = project_root / "configs"
        configs_saving = saving_root / "configs"
        #if configs_saving.exists():
        #    raise RuntimeError("config files already exists!")
        #copytree(configs_path, configs_saving)

        # Dataset
        DS = DatasetFactory.get_dataset_type(use_future_fea, use_static)

        # Training data
        ds_train = DS.get_instance(past_len, pred_len, "train", specific_cfg=pre_train_config)
        train_loader = DataLoader(ds_train, batch_size=batch_size, num_workers=num_workers, shuffle=True)

        # We use the feature means/stds of the training data for normalization in val and test stage
        train_x_mean, train_y_mean = ds_train.get_means()
        train_x_std, train_y_std = ds_train.get_stds()
        y_stds_dict = ds_train.y_stds_dict
        # Saving training mean and training std
        train_means = np.concatenate((train_x_mean, train_y_mean), axis=0)
        train_stds = np.concatenate((train_x_std, train_y_std), axis=0)
        np.savetxt(saving_root / "train_means.csv", train_means)
        np.savetxt(saving_root / "train_stds.csv", train_stds)
        with open(saving_root / "y_stds_dict.json", "wt") as f:
            json.dump(y_stds_dict, f)

        # Validation data (needs training mean and training std)
        ds_val = DS.get_instance(past_len, pred_len, "val", specific_cfg=pre_val_config,
                                 x_mean=train_x_mean, y_mean=train_y_mean, x_std=train_x_std, y_std=train_y_std,
                                 y_stds_dict=y_stds_dict)
        val_loader = DataLoader(ds_val, batch_size=batch_size, num_workers=num_workers, shuffle=False)

        # Testing data (needs training mean and training std)
        ds_test = DS.get_instance(past_len, pred_len, "test", specific_cfg=pre_test_config,
                                  x_mean=train_x_mean, y_mean=train_y_mean, x_std=train_x_std, y_std=train_y_std,
                                  y_stds_dict=y_stds_dict)
        test_loader = DataLoader(ds_test, batch_size=batch_size, num_workers=num_workers, shuffle=False)

        # Model, Optimizer, Scheduler, Loss
        model = Model().to(device)
        optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
        scheduler = SchedulerFactory.get_scheduler(optimizer, **scheduler_paras)
        loss_func = loss_func.to(device)

        # Training and Validation
        train_full(model, decode_mode, train_loader, val_loader, optimizer, scheduler, loss_func, n_epochs, device,
                   saving_root)
        
        # Save the model for the current fold
        torch.save(model.state_dict(), saving_root / f"model_training_global.pt")