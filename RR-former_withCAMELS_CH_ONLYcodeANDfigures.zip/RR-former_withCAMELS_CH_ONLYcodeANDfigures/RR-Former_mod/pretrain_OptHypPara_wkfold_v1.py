import torch
import os
import numpy as np
import json
import importlib
import shutil
from shutil import copytree
from torch.utils.data import DataLoader
from sklearn.model_selection import KFold, StratifiedKFold
import optuna
from optuna.pruners import HyperbandPruner
from optuna.samplers import TPESampler
from optuna.visualization import plot_optimization_history, plot_param_importances, plot_timeline, plot_contour

from configs.project_config import ProjectConfig
from configs.data_shape_config import DataShapeConfig
from configs.dataset_config import DatasetConfig
from configs.run_config.pretrain_config import PretrainConfig
from configs.run_config.pretrain_config import PretrainLearningConfig  # we add this
from utils.tools import SeedMethods
from utils.lr_strategies import SchedulerFactory
from utils.train_full import train_full
from data.dataset import DatasetFactory

project_root = ProjectConfig.project_root
device = ProjectConfig.device
num_workers = ProjectConfig.num_workers

past_len = DataShapeConfig.past_len
pred_len = DataShapeConfig.pred_len
src_len = DataShapeConfig.src_len
tgt_len = DataShapeConfig.tgt_len
src_size = DataShapeConfig.src_size
tgt_size = DataShapeConfig.tgt_size
use_future_fea = DataShapeConfig.use_future_fea
use_static = DataShapeConfig.use_static

kfold_basin_split = DatasetConfig.kfold_basin_split
num_folds = DatasetConfig.num_folds
kfold_type = DatasetConfig.kfold_type

used_model = PretrainConfig.used_model
decode_mode = PretrainConfig.decode_mode
#dropout = PretrainConfig.dropout # we add this
pre_train_config = PretrainConfig.pre_train_config
pre_val_config = PretrainConfig.pre_val_config
pre_test_config = PretrainConfig.pre_test_config
loss_func = PretrainConfig.loss_func
n_epochs = PretrainConfig.n_epochs
warmup_frac = PretrainConfig.warmup_frac
batch_size = PretrainConfig.batch_size
learning_rate = PretrainConfig.learning_rate
scheduler_paras = PretrainConfig.scheduler_paras
weight_dr = PretrainConfig.weight_dr # we add this

seed = PretrainConfig.seed
saving_message = PretrainConfig.saving_message
saving_root = PretrainConfig.saving_root

model_info = PretrainConfig.model_info # we add this

# The objective function is defined outside of the if __name__ == '__main__': 
# block because it needs to be accessible to the Optuna study, 
# which calls this function during the optimization process.
# Optuna requires the objective function to be defined at the module level
# so that it can be serialized/deserialized and executed by the Optuna framework.

def objective(trial, used_model, fold_idx,
              pre_train_config, pre_val_config, pre_test_config,
              past_len, pred_len, num_workers):

    # Suggest hyperparameters
    #dropout = trial.suggest_categorical('dropout', [1e-4, 1e-3, 1e-2])
    #dropout_rate = trial.suggest_float('dropout_rate', 0.0, 0.5) #TODO if you want to optmize the dropput_rate
    dropout_rate = trial.suggest_categorical('dropout_rate', [ 1e-1, 2e-1])
    if used_model == "Transformer":
        dmodel = trial.suggest_categorical('dmodel', [64, 128, 256, 512])
    #learning_rate = trial.suggest_loguniform('learning_rate', 1e-5, 1e-1)
    learning_rate = trial.suggest_categorical('learning_rate', [1e-4, 1e-3, 1e-2])
    batch_size = trial.suggest_categorical('batch_size', [64, 128, 256, 512])
    #weight_dr = trial.suggest_uniform('weight_dr', 0.0, 0.5)
    weight_dr = trial.suggest_categorical('weight_dr', [1e-3, 1e-2, 1e-1,2e-1])

    # Import the model configuration
    used_model_config = importlib.import_module(f"configs.model_config.{used_model}_config")
    used_ModelConfig = getattr(used_model_config, f"{used_model}Config")

    # Update model configuration with the optimized dropout_rate or some model dimension
    # **Uncomment the next few lines only if you want to optimize hyperparameters
    #   defined in the models' configuration**
    used_ModelConfig.dropout_rate = dropout_rate
    if used_model == "Transformer":
        used_ModelConfig.dmodel = dmodel

    #train_kfold(train_basins, val_basins, test_basins, fold_idx, dropout, learning_rate, batch_size, weight_dr)
    train_kfold(fold_idx, learning_rate, batch_size, weight_dr,
                pre_train_config, pre_val_config, pre_test_config,
                past_len, pred_len, num_workers)
    
#def train_kfold(train_basins, val_basins, test_basins, fold_idx, dropout, learning_rate, batch_size, weight_dr):
def train_kfold(fold_idx, learning_rate, batch_size, weight_dr,
                pre_train_config, pre_val_config, pre_test_config,
                past_len, pred_len, num_workers):

     # Training data
    ds_train = DS.get_instance(past_len, pred_len, "train", specific_cfg=pre_train_config)
    train_loader = DataLoader(ds_train, batch_size=batch_size, num_workers=num_workers, shuffle=True)

    # Compute means and stds for the current fold
    train_x_mean, train_y_mean = ds_train.get_means()
    train_x_std, train_y_std = ds_train.get_stds()
    y_stds_dict = ds_train.y_stds_dict

    # Saving training mean and training std for the current fold
    train_means = np.concatenate((train_x_mean, train_y_mean), axis=0)
    train_stds = np.concatenate((train_x_std, train_y_std), axis=0)
    np.savetxt(saving_root / f"train_means_fold_{fold_idx}.csv", train_means)
    np.savetxt(saving_root / f"train_stds_fold_{fold_idx}.csv", train_stds)
    with open(saving_root / f"y_stds_dict_fold_{fold_idx}.json", "wt") as f:
                json.dump(y_stds_dict, f)

    # Validation data (needs training mean and training std for the current fold)
    ds_val = DS.get_instance(past_len, pred_len, "val", specific_cfg=pre_val_config,
                        x_mean=train_x_mean, y_mean=train_y_mean, x_std=train_x_std, y_std=train_y_std,
                        y_stds_dict=y_stds_dict)
    val_loader = DataLoader(ds_val, batch_size=batch_size, num_workers=num_workers, shuffle=False)

    # Testing data (needs training mean and training std)
    ds_test = DS.get_instance(past_len, pred_len, "test", specific_cfg=pre_test_config,
                        x_mean=train_x_mean, y_mean=train_y_mean, x_std=train_x_std, y_std=train_y_std,
                        y_stds_dict=y_stds_dict)
    test_loader = DataLoader(ds_test, batch_size=batch_size, num_workers=num_workers, shuffle=False)

    # Model, Optimizer, Scheduler, Loss for the current fold
    model = Model().to(device)
    #optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate) # we change this
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate, weight_decay= weight_dr)
    scheduler = SchedulerFactory.get_scheduler(optimizer, **scheduler_paras)
    loss_func = loss_func.to(device)

    if fold_idx == 0:

        # Training and Validation for the first fold => save validation loss for optimization!
        val_loss = train_full(model, decode_mode, train_loader, val_loader, optimizer, scheduler, loss_func, n_epochs, device,
                        saving_root / f"fold_{fold_idx}")
        return val_loss
    
    else:

        # Training and Validation for the current fold
        train_full(model, decode_mode, train_loader, val_loader, optimizer, scheduler, loss_func, n_epochs, device,
                       saving_root / f"fold_{fold_idx}")

    # Save the model for the current fold
    torch.save(model.state_dict(), saving_root / f"model_training_fold_{fold_idx}.pt")


if __name__ == '__main__': # Note: this is a conditional block that determines whether a script is being run directly or imported as a module.
    # Code organization: It helps to separate the main program logic from reusable functions and classes.
    # Testing: It allows you to include test cases within the same script without running them when the module is imported.
    # Reusability: It ensures that the script can be imported as a module without unintended side effects.

    print("pid:", os.getpid())
    SeedMethods.seed_torch(seed=seed)
    #saving_root.mkdir(exist_ok=True, parents=True)
    #print(saving_root)
    # Saving config files
    #configs_path = project_root / "configs"
    #configs_saving = saving_root / "configs"
    #if configs_saving.exists():
    #    raise RuntimeError("config files already exists!")
    #copytree(configs_path, configs_saving)

    # Define model type
    models = importlib.import_module("models")
    Model = getattr(models, used_model)

    # Get list of basins
    all_basins = DatasetConfig.global_basins_list

    if kfold_basin_split:

        # Define ignore patterns for copying configs
        def ignore_files_and_dirs(src, names):
            ignore_list = []
            for name in names:
                if name == '__pycache__' or name.endswith('.pyc') or name.endswith('.pyo') or name.endswith('~'):
                    ignore_list.append(name)
            return set(ignore_list)
        
        def copy_tree_with_ignore(src, dst, ignore=None):
            try:
                shutil.copytree(src, dst, ignore=ignore)
            except shutil.Error as e:
                print(f"Error occurred while copying: {e}")
            except OSError as e:
                print(f"OS error occurred: {e}")


        # Perform k-fold splitting
        if kfold_type == "strat":
            # Get list of class labels
            all_classes = DatasetConfig.global_classes_list
            if all_classes is not None:
                skf = StratifiedKFold(n_splits=num_folds, shuffle=True, random_state=seed)
                basin_splits = list(skf.split(all_basins, all_classes))
            else:
                raise FileNotFoundError(f"Class list file is somehow missing, but required for stratified k-fold.")
        else:
            kf = KFold(n_splits=num_folds, shuffle=True, random_state=seed)
            basin_splits = list(kf.split(all_basins))

        for fold_idx, (train_idx, val_idx) in enumerate(basin_splits):

            # Generate saving message and root for each fold
            saving_message = f"{model_info}@{DatasetConfig.dataset_info}@{DataShapeConfig.data_shape_info}" \
                             f"@{PretrainLearningConfig.learning_config_info}@seed{seed}@fold{fold_idx}"
            saving_root = ProjectConfig.run_root / saving_message

            # Ensure the saving_root directory exists
            saving_root.mkdir(exist_ok=True, parents=True)
            print(saving_root)

            # Saving config files
            configs_path = project_root / "configs"
            configs_saving = saving_root / "configs"
            if configs_saving.exists():
                raise RuntimeError("config files already exists!")
            #copytree(configs_path, configs_saving)
            copy_tree_with_ignore(configs_path, configs_saving, ignore=ignore_files_and_dirs)

            # Initialize sets for fold indices
            folds = set(range(num_folds))
            val_folds = {fold_idx % num_folds}
            test_folds = {(fold_idx + 1) % num_folds}
            train_folds = folds - val_folds - test_folds

            # Convert basin indices to a set for easier manipulation
            basin_indices_set = set(range(len(all_basins)))

            # Assign basins to train, valid, and test based on fold assignments
            train_basins = [all_basins[i] for i in basin_indices_set if i % num_folds in train_folds]
            val_basins = [all_basins[i] for i in basin_indices_set if i % num_folds in val_folds]
            test_basins = [all_basins[i] for i in basin_indices_set if i % num_folds in test_folds]

            # Overwrite configurations for each fold
            pre_train_id = f"{DatasetConfig.forcing_type}{DatasetConfig.basin_mark}@{DataShapeConfig.data_shape_info}" \
                        f"@fold{fold_idx}@{DatasetConfig.train_start.date()}~{DatasetConfig.train_end.date()}"
            pre_val_id = f"{DatasetConfig.forcing_type}{DatasetConfig.basin_mark}@{DataShapeConfig.data_shape_info}" \
                        f"@fold{fold_idx}@{DatasetConfig.val_start.date()}~{DatasetConfig.val_end.date()}"
            pre_test_id = f"{DatasetConfig.forcing_type}{DatasetConfig.basin_mark}@{DataShapeConfig.data_shape_info}" \
                        f"@fold{fold_idx}@{DatasetConfig.test_start.date()}~{DatasetConfig.test_end.date()}"

            final_train_data_path = ProjectConfig.final_data_root / f"{pre_train_id}_serialized_train.pkl"
            final_val_data_path = ProjectConfig.final_data_root / f"{pre_val_id}_serialized_val.pkl"
            final_test_data_path = ProjectConfig.final_data_root / f"{pre_test_id}_serialized_test.pkl"

            pre_train_config = {
                "camels_root": DatasetConfig.camels_root,
                "basins_list": train_basins,
                "forcing_type": DatasetConfig.forcing_type,
                "start_date": DatasetConfig.train_start,
                "end_date": DatasetConfig.train_end,
                "final_data_path": final_train_data_path
            }

            pre_val_config = {
                "camels_root": DatasetConfig.camels_root,
                "basins_list": val_basins,
                "forcing_type": DatasetConfig.forcing_type,
                "start_date": DatasetConfig.val_start,
                "end_date": DatasetConfig.val_end,
                "final_data_path": final_val_data_path
            }

            pre_test_config = {
                "camels_root": DatasetConfig.camels_root,
                "basins_list": test_basins,
                "forcing_type": DatasetConfig.forcing_type,
                "start_date": DatasetConfig.test_start,
                "end_date": DatasetConfig.test_end,
                "final_data_path": final_test_data_path
            }


            # Dataset
            DS = DatasetFactory.get_dataset_type(use_future_fea, use_static)

            if fold_idx == 0:

                print("Start optimization using first fold")

                # Set up Optuna study
                # Define sampler and pruner
                sampler = TPESampler(consider_prior=False, n_startup_trials=25, seed=1, multivariate=True)
                pruner = HyperbandPruner(min_resource=10, reduction_factor=3)

                # Create Optuna study and optimize
                study = optuna.create_study(sampler=sampler, pruner=pruner, direction='minimize')
                study.optimize(lambda trial: objective(trial, used_model, fold_idx,
                                                       pre_train_config, pre_val_config, pre_test_config,
                                                       past_len, pred_len, num_workers),n_trials=100)
                
                # Save the best hyperparameters
                best_hyperparams = study.best_params
                with open(os.path.join(saving_root, 'best_hyperparams.json'), 'w') as f:
                    json.dump(best_hyperparams, f)

                # Load the best hyperparameters
                with open(os.path.join(saving_root, 'best_hyperparams.json'), 'r') as f:
                    best_hyperparams = json.load(f)

                # Update PretrainConfig with the best hyperparameters
                #PretrainConfig.dropout = best_hyperparams['dropout']
                PretrainConfig.learning_rate = best_hyperparams['learning_rate']
                PretrainConfig.batch_size = best_hyperparams['batch_size']
                PretrainConfig.weight_dr = best_hyperparams['weight_dr']

                # Generate and save several types of visualization
                # You might also consider installing Optuna Dashboard for VS Code?
                # (later on, you can run 'optuna-dashboard sqlite:///study.db' in the terminal)
                optimization_history = plot_optimization_history(study)
                param_importances = plot_param_importances(study)
                optimization_timeline = plot_timeline(study)
                optimization_history = plot_contour

                # Save study, so later on you can compare different studies
                # e.g. performed using different models
                study_name = f"study_do_lr_bs_wdr_dm_{fold_idx}.db" #TODO add acronyms os optmized parameters to the name
                study_storage = f"sqlite:///{os.path.join(saving_root, study_name)}"
            
            else:

                print(f"Continue cross validation on remaining folds, now fold: {fold_idx}")

                # Use the best parameters from the first fold
                #dropout = best_hyperparams['dropout']
                learning_rate = best_hyperparams['learning_rate']
                batch_size = best_hyperparams['batch_size']
                weight_dr = best_hyperparams['weight_dr']

                # Training and Validation for the current fold
                train_kfold(fold_idx, learning_rate, batch_size, weight_dr,
                pre_train_config, pre_val_config, pre_test_config,
                past_len, pred_len, num_workers)
    else:

        # No k-fold splitting

        # Ensure the saving_root directory exists
        saving_root.mkdir(exist_ok=True, parents=True)
        print(saving_root)

        # Saving config files
        configs_path = project_root / "configs"
        configs_saving = saving_root / "configs"
        if configs_saving.exists():
            raise RuntimeError("config files already exists!")
        copytree(configs_path, configs_saving)

        # Dataset
        DS = DatasetFactory.get_dataset_type(use_future_fea, use_static)

        # Training data
        ds_train = DS.get_instance(past_len, pred_len, "train", specific_cfg=pre_train_config)
        train_loader = DataLoader(ds_train, batch_size=batch_size, num_workers=num_workers, shuffle=True)

        # We use the feature means/stds of the training data for normalization in val and test stage
        train_x_mean, train_y_mean = ds_train.get_means()
        train_x_std, train_y_std = ds_train.get_stds()
        y_stds_dict = ds_train.y_stds_dict
        # Saving training mean and training std
        train_means = np.concatenate((train_x_mean, train_y_mean), axis=0)
        train_stds = np.concatenate((train_x_std, train_y_std), axis=0)
        np.savetxt(saving_root / "train_means.csv", train_means)
        np.savetxt(saving_root / "train_stds.csv", train_stds)
        with open(saving_root / "y_stds_dict.json", "wt") as f:
            json.dump(y_stds_dict, f)

        # Validation data (needs training mean and training std)
        ds_val = DS.get_instance(past_len, pred_len, "val", specific_cfg=pre_val_config,
                                 x_mean=train_x_mean, y_mean=train_y_mean, x_std=train_x_std, y_std=train_y_std,
                                 y_stds_dict=y_stds_dict)
        val_loader = DataLoader(ds_val, batch_size=batch_size, num_workers=num_workers, shuffle=False)

        # Testing data (needs training mean and training std)
        ds_test = DS.get_instance(past_len, pred_len, "test", specific_cfg=pre_test_config,
                                  x_mean=train_x_mean, y_mean=train_y_mean, x_std=train_x_std, y_std=train_y_std,
                                  y_stds_dict=y_stds_dict)
        test_loader = DataLoader(ds_test, batch_size=batch_size, num_workers=num_workers, shuffle=False)

        # Model, Optimizer, Scheduler, Loss
        model = Model().to(device)
        optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
        scheduler = SchedulerFactory.get_scheduler(optimizer, **scheduler_paras)
        loss_func = loss_func.to(device)

        # Training and Validation
        train_full(model, decode_mode, train_loader, val_loader, optimizer, scheduler, loss_func, n_epochs, device,
                   saving_root)
        
        # Save the model for the current fold
        torch.save(model.state_dict(), saving_root / f"model_training_global.pt")