import numpy as np
import pandas as pd
import torch

from torch.utils.data import Dataset
from pathlib import Path
from bisect import bisect_right
from abc import ABCMeta, abstractmethod

from configs.dataset_config import DatasetConfig

class AbstractReader(metaclass=ABCMeta):
    """Abstract data reader.

    Its subclasses need to ensure conversion from raw data to pandas.DataFrame,
    and process invalid data item
    """

    @abstractmethod
    def _load_data(self, *args, **kwargs):
        """
        Subclasses must implement loading inputs and target data.
        """
        pass

    @abstractmethod
    def _process_invalid_data(self, *args, **kwargs):
        """
        Subclasses must implement how to process invalid data item.
        """
        pass

    @abstractmethod
    def get_df_x(self):
        """
        Subclasses must return inputs data with a form of pandas.DataFrame.
        """
        pass

    @abstractmethod
    def get_df_y(self):
        """
        Subclasses must return target data with a form of pandas.DataFrame.
        """
        pass


class AbstractStaticReader:
    """Abstract static data reader.

    1. Reads data from a static attributes file (.csv).
    2. Select used attributes and do normalization. **MK: this is not done really? We will add normalization!**
    3. Need to ensure conversion from static attributes to pandas.DataFrame.
    """

    @abstractmethod
    def get_df_static(self, basin):
        """
        Subclasses must return static data with a form of pandas.DataFrame for a specific basin
        """
        pass


class DaymetHydroReader(AbstractReader):
    camels_root = None  # needs to be set in class method "init_root"
    forcingOBS_root = None
    forcingSIM_root = None
    forcingOBS_cols = ["date", "discharge_vol(m3/s)", "discharge_spec(mm/d)", "waterlevel(m)",
                        "precipitation(mm/d)", "temperature_min(degC)", "temperature_mean(degC)", "temperature_max(degC)",
                        "rel_sun_dur(%)", "swe(mm)"]
    target = ["discharge_spec(mm/d)"]
    #featuresOBS = ["precipitation(mm/d)", "temperature_min(degC)", "temperature_max(degC)", "swe(mm)"]
    featuresOBS = ["precipitation(mm/d)", "temperature_min(degC)", "temperature_max(degC)"]
    selectionOBS = target + featuresOBS
    forcingSIM_cols = ["date", "discharge_vol_sim(m3/s)", "discharge_spec_sim(mm/d)", "precipitation_sim(mm/d)",
                        "temperature_sim(degC)", "radiation_sim(W/m2)", "sun_duration_sim(h)", "wind_sim(m/s)",
                        "rel_humidity_sim(%)", "pet_sim(mm/d)", "et_sim(mm/d)", "intercept_et_sim(mm/d)", "intercept_storage_sim(mm)"]
    #featuresSIM = ["pet_sim(mm/d)"] # we can put this back in, when we wil have P, Tmin and Tmax for all basins
                                     # see also the comments in  _load_data method
    featuresSIM = ["precipitation_sim(mm/d)", "temperature_sim(degC)", "pet_sim(mm/d)"]
    #features = featuresOBS + featuresSIM
    features = featuresOBS + ["pet_sim(mm/d)"]

    @classmethod
    def init_root(cls, camels_root):  # often be rewritten
        cls.camels_root = Path(camels_root)
        cls.forcingOBS_root = cls.camels_root / "timeseries" / "observation_based"
        cls.forcingSIM_root = cls.camels_root / "timeseries" / "simulation_based"

    def __init__(self, basin: str):
        self.basin = basin
        self.area = None
        df = self._load_data()
        df = self._process_invalid_data(df)
        self.df_x = df[self.features]  # Datetime as index
        self.df_y = df[self.target]  # Datetime as index

    def get_df_x(self):
        return self.df_x

    def get_df_y(self):
        return self.df_y

    def _load_data(self):
        df_forcingOBS = self._load_forcingOBS()
        df_forcingSIM = self._load_forcingSIM()
        # Note: We cannot add snow, as there are no values for too many catchments
        # in principle all those outside of the Swiss national boundaries..
        # If we could find a product to fill swe for all catchments, we could uncomment the following line
        # Note: we think snow would be a beneficial variable to include in the model
        #df = pd.concat([df_forcingOBS[["precipitation(mm/d)", "temperature_min(degC)", "temperature_max(degC)", "swe(mm)"]], 
        
        # Define the columns where many NaNs are found in the observations => and take simulated values instead
        # (this should be fine for only so few basins)
        # Note: this seems to happen mainly for just some subcatchments outside of the Swiss national boundaries
        # in particular basins
        # basins_withNaN_intraining = ["4001", "4008", "4011", "4014", "4017", "4021", "4025", "5006", "5015", "5019"]
        col_P_Tmin_Tmax = ["precipitation(mm/d)", "temperature_min(degC)", "temperature_max(degC)"]

        # Define the threshold for the maximum number of NaNs allowed
        nan_threshold = 32000  # Adjust this value as needed (ca 14610 lines*0.75 of data coverage *3 variables)

        # Calculate the number of NaNs in the specified columns of df_forcingOBS
        num_nans = df_forcingOBS[col_P_Tmin_Tmax].isna().sum().sum()
        # Print number of NaNs for debugging
        #print("Number of NaNs in the specified columns of df_forcingOBS:", num_nans)

        # Select the appropriate DataFrame based on the number of NaNs
        if num_nans > nan_threshold:
            # Houston, we have a problem..
            # For some reason the simulated temperature is only reported as mean, no min and max are provided
            # We will extract these data later, there was probably an error in the extraction of the data
            # performed by Rosi on the MeteoSwiss data?!
            # For now let's fill it with the rather brutal approach of removing/adding 1.5 degrees to the simulated mean temperature
            df = pd.concat([df_forcingSIM["precipitation_sim(mm/d)"], 
                            df_forcingSIM["temperature_sim(degC)"] - 1.5, 
                            df_forcingSIM["temperature_sim(degC)"]+ 1.5,  
                            df_forcingSIM["pet_sim(mm/d)"], 
                            df_forcingOBS["discharge_spec(mm/d)"]], axis=1)
            # Rename the columns to match the original names you would have used if using observed meterological variables
            df.columns = ["precipitation(mm/d)", "temperature_min(degC)", "temperature_max(degC)", "pet_sim(mm/d)", "discharge_spec(mm/d)"]
            # Print column names for debugging
            #print("Columns after concatenation and renaming:", df.columns)
        else:
            selected_columns = df_forcingOBS[col_P_Tmin_Tmax]
            # Concatenate the selected columns with other necessary columns
            df = pd.concat([selected_columns, 
                        df_forcingSIM["pet_sim(mm/d)"], 
                        df_forcingOBS["discharge_spec(mm/d)"]], axis=1)


        #df = pd.concat([df_forcingOBS[["precipitation(mm/d)", "temperature_min(degC)", "temperature_max(degC)"]], 
        #df_forcingSIM["pet_sim(mm/d)"], 
        #df_forcingOBS["discharge_spec(mm/d)"]], axis=1)

        return df

    # Loading observation based data
    def _load_forcingOBS(self):
        files = list(self.forcingOBS_root.glob(f"**/CAMELS_CH_obs_based_{self.basin}*.csv"))
        if len(files) == 0:
            raise RuntimeError(f"No forcing file found for Basin {self.basin}")
        elif len(files) >= 2:
            raise RuntimeError(f"Redundant forcing files found for Basin {self.basin}")
        else:
            file_path = files[0]

         # read-in data and get date
        df = pd.read_csv(file_path, header=0)
        date = df.date
        df.index = pd.to_datetime(date, format="%Y-%m-%d")

        return df[self.selectionOBS]

    # Loading simulation based data
    def _load_forcingSIM(self):
        files = list(self.forcingSIM_root.glob(f"**/CAMELS_CH_sim_based_{self.basin}*.csv"))
        if len(files) == 0:
            raise RuntimeError(f"No discharge file found for Basin {self.basin}")
        elif len(files) >= 2:
            raise RuntimeError(f"Redundant discharge files found for Basin {self.basin}")
        else:
            file_path = files[0]

         # read-in data and get date
        df = pd.read_csv(file_path, header=0)
        date = df.date
        df.index = pd.to_datetime(date, format="%Y-%m-%d")

        return df[self.featuresSIM]

    # Processing invalid data
    def _process_invalid_data(self, df: pd.DataFrame):
        # Delete all row, where exits NaN (only discharge has NaN in this dataset)
        len_raw = len(df)
        df = df.dropna()
        len_drop_nan = len(df)
        if len_raw > len_drop_nan:
            print(f"Deleted {len_raw - len_drop_nan} records because of NaNs {self.basin}")

        # Deletes all records, where no discharge was measured (-999)
        df = df.drop((df[df["discharge_spec(mm/d)"] < 0]).index)
        len_drop_neg = len(df)
        if len_drop_nan > len_drop_neg:
            print(f"Deleted {len_drop_nan - len_drop_neg} records because of negative discharge {self.basin}")

        return df


class HydroReaderFactory:
    """
    Simple factory for producing HydroReader
    """

    @staticmethod
    def get_hydro_reader(camels_root, forcing_type, basin):
        if forcing_type == "daymet":
            DaymetHydroReader.init_root(camels_root)
            reader = DaymetHydroReader(basin)
        else:
            raise RuntimeError(f"No such hydro reader type: {forcing_type}")

        return reader


class CamelsDataset(Dataset):
    """CAMELS dataset working with subclasses of AbstractHydroReader.

    It works in a list way: the model trains, validates and tests with all of basins in attribute:basins_list.

    Attributes:
        camels_root: str
            The root of CAMELS dataset.
        basins_list: list of str
            A list contains all needed basins-ids (8-digit code).
        past_len: int
            Length of the past time steps for discharge data.
        pred_len: int
            Length of the predicting time steps for discharge data.
            And it is worth noting that the used length of meteorological data is (past_len + :pred_len).
        stage: str
            One of ['train', 'val', 'test'], decide whether calculating mean and std or not.
            Calculate mean and std in training stage.
        dates: List of pd.DateTimes
            Means the date range that is used, containing two elements, i.e, start date and end date.
        x_dict: dict as {basin: np.ndarray}
             Mapping a basin to its corresponding meteorological data.
        y_dict: dict as {basin: np.ndarray}
             Mapping a basin to its corresponding discharge data.
        length_ls: list of int
            Contains number of serialized sequences of each basin corresponding to basins_list.
        index_ls: list of int
            Created from length_ls, used in __getitem__ method.
        num_samples: int
            Number of serialized sequences of all basins.
        x_mean: numpy.ndarray
            Mean of input features derived from the training stage.
            Has to be provided for 'val' or 'test' stage.
            Can be retrieved if calling .get_means() on the data set.
        y_mean: numpy.ndarray
            Mean of output features derived from the training stage.
            Has to be provided for 'val' or 'test' stage.
            Can be retrieved if calling .get_means() on the data set.
        x_std: numpy.ndarray
            Std of input features derived from the training stage.
            Has to be provided for 'val' or 'test' stage.
            Can be retrieved if calling .get_stds() on the data set.
        y_std: numpy.ndarray
            Std of output features derived from the training stage.
            Has to be provided for 'val' or 'test' stage.
            Can be retrieved if calling .get_stds() on the data set.
    """

    def __init__(self, camels_root: str, forcing_type: str, basins_list: list, past_len: int, pred_len: int, stage: str,
                 dates: list, x_mean=None, y_mean=None, x_std=None, y_std=None, y_stds_dict=None):
        """Initialization

        x_mean, y_mean, x_std, y_std should be provided if stage != "train".
        """
        self.camels_root = camels_root
        self.basins_list = basins_list
        self.past_len = past_len
        self.pred_len = pred_len
        self.stage = stage
        self.dates = dates
        self.x_dict = dict()
        self.y_dict = dict()
        self.date_index_dict = dict()
        self.length_ls = list()

        if y_stds_dict is None:
            self.y_stds_dict = dict()
        else:
            self.y_stds_dict = y_stds_dict

        self._load_data(forcing_type)
        # Calculate mean and std
        if self.stage == 'train':
            self.x_mean, self.x_std = self.calc_mean_and_std(self.x_dict)
            self.y_mean, self.y_std = self.calc_mean_and_std(self.y_dict)
        else:
            self.x_mean = x_mean
            self.y_mean = y_mean
            self.x_std = x_std
            self.y_std = y_std
        self.normalize_data()

        self.num_samples = 0
        for item in self.length_ls:
            self.num_samples += item

        self.index_ls = [0]
        for i in range(len(self.length_ls)):
            v = self.index_ls[i] + self.length_ls[i]
            self.index_ls.append(v)

    def __len__(self):
        return self.num_samples

    def __getitem__(self, idx: int):
        #if self.stage == 'val' or self.stage == 'test':
        #    print("I am in getitem for validation or test stage (CamelsDataset(Dataset))")

        basin_idx = bisect_right(self.index_ls, idx) - 1
        local_idx = idx - self.index_ls[basin_idx]
        basin = self.basins_list[basin_idx]

        #if self.stage == 'val' or self.stage == 'test':
        #    print(f"basin_idx: {basin_idx}, local_idx: {local_idx}, basin: {basin}")

        x_seq = self.x_dict[basin][local_idx: local_idx + self.past_len + self.pred_len, :]
        y_seq_past = self.y_dict[basin][local_idx: local_idx + self.past_len, :]
        y_seq_future = self.y_dict[basin][local_idx + self.past_len: local_idx + self.past_len + self.pred_len, :]

        return x_seq, y_seq_past, y_seq_future, self.y_stds_dict[basin]

    def _load_data(self, forcing_type):
        #if self.stage == 'val' or self.stage == 'test':
        #    print("I am loading the data for validation or test stage(CamelsDataset(Dataset))")

        # Loading vanilla data
        basin_number = len(self.basins_list)
        for idx, basin in enumerate(self.basins_list):
            print(self.stage, f"{basin}: loading data %.4f" % (idx / basin_number))
            reader = HydroReaderFactory.get_hydro_reader(self.camels_root, forcing_type, basin)
            df_x = reader.get_df_x()
            df_y = reader.get_df_y()

            # Select date
            df_x = df_x[self.dates[0]:self.dates[1]]
            df_y = df_y[self.dates[0]:self.dates[1]]
            assert len(df_x) == len(df_y)
            self.date_index_dict[basin] = df_x.index

            # Select used features and discharge
            x = df_x.values.astype("float32")
            y = df_y.values.astype("float32")
            self.x_dict[basin] = x
            self.y_dict[basin] = y

            self.length_ls.append(len(x) - self.past_len - self.pred_len + 1)
            # Calculate mean and std in training stage
            if self.stage == 'train':
                self.y_stds_dict[basin] = y.std(axis=0).item()

    @staticmethod
    def calc_mean_and_std(data_dict):
        data_all = np.concatenate(list(data_dict.values()), axis=0)  # CAN NOT serializable
        nan_mean = np.nanmean(data_all, axis=0)
        nan_std = np.nanstd(data_all, axis=0)
        return nan_mean, nan_std

    def _local_normalization(self, feature: np.ndarray, variable: str) -> np.ndarray:
        if variable == 'inputs':
            feature = (feature - self.x_mean) / self.x_std
        elif variable == 'output':
            feature = (feature - self.y_mean) / self.y_std
        else:
            raise RuntimeError(f"Unknown variable type {variable}")
        return feature

    def normalize_data(self):
        # Normalize data
        for idx, basin in enumerate(self.basins_list):
            print(self.stage, "Normalizing %.4f" % (idx / len(self.basins_list)))
            x = self.x_dict[basin]
            y = self.y_dict[basin]
            # Normalize data
            x_norm = self._local_normalization(x, variable='inputs')
            y_norm = self._local_normalization(y, variable='output')
            self.x_dict[basin] = x_norm
            self.y_dict[basin] = y_norm

    def local_rescale(self, feature: np.ndarray, variable: str) -> np.ndarray:
        if variable == 'inputs':
            feature = feature * self.x_std + self.x_mean
        elif variable == 'output':
            feature = feature * self.y_std + self.y_mean
        else:
            raise RuntimeError(f"Unknown variable type {variable}")
        return feature

    def get_means(self):
        return self.x_mean, self.y_mean

    def get_stds(self):
        return self.x_std, self.y_std

    @classmethod
    def get_instance(cls, past_len: int, pred_len: int, stage: str, specific_cfg: dict,
                     x_mean=None, y_mean=None, x_std=None, y_std=None, y_stds_dict=None):
        final_data_path = specific_cfg["final_data_path"]
        camels_root = specific_cfg["camels_root"]
        basins_list = specific_cfg["basins_list"]
        forcing_type = specific_cfg["forcing_type"]
        start_date = specific_cfg["start_date"]
        end_date = specific_cfg["end_date"]
        if final_data_path is None:
            dates = [start_date, end_date]
            instance = cls(camels_root, forcing_type, basins_list, past_len, pred_len, stage,
                           dates, x_mean, y_mean, x_std, y_std, y_stds_dict)
            return instance
        else:
            if final_data_path.exists():
                instance = torch.load(final_data_path)
                return instance
            else:
                dates = [start_date, end_date]
                instance = cls(camels_root, forcing_type, basins_list, past_len, pred_len, stage,
                               dates, x_mean, y_mean, x_std, y_std, y_stds_dict)
                final_data_path.parent.mkdir(exist_ok=True, parents=True)
                torch.save(instance, final_data_path)
                return instance


class StaticReader(AbstractStaticReader):
    """Static hydrological data reader.

    **Reads data from a selected norm static attributes file (.csv).** I think this is wrong and it should be:
    Reads data from a selected static attributes file (.csv).
    Need to ensure conversion from static attributes to pandas.DataFrame.
    """

    def __init__(self, camels_root, basins_list=None, final_data_path=None):
    #def __init__(self, camels_root, basins_list=None):
    #def __init__(self, camels_root): # **..**

        self.camels_root = Path(camels_root)
        self.basins = basins_list if basins_list is not None else []

         # If final_data_path is None, use the global basins list for standardization
        if final_data_path is None:
            self.basins = DatasetConfig.global_basins_list

        # Load the static attributes file
        #self.static_file_path = camels_root / "static_attributes" / "selected_norm_static_attributes.csv" # commented because of the issue **above**
        self.static_file_path = camels_root / "static_attributes" / "selected_static_attributes.csv"
        self.df_static = pd.read_csv(self.static_file_path, sep=';', header=0, dtype={"gauge_id": str}).set_index("gauge_id")
        self.df_static = self.df_static.astype("float32")

        # We add this so that static attributes are normalized implicitly
        # depending on the basin_list resp. split, if kfold xvalidation is performed# **..**
        #if self.basins:
        #if isinstance(self.basins, str): # we don't need this, because it is already a list
            #self.basins = [self.basins] # we don't need this, because it is already a list
            #df_static_selected = self.df_static.loc[self.basins]
            #self.df_static = self._standardize_static_data(df_static_selected)

        # Standardize based on global basins list if final_data_path is None
        if final_data_path is None:
            #df_static_selected = self.df_static.loc[DatasetConfig.global_basins_list]
            glob_bas_list = pd.read_csv("S:/tina/AML/P3/RR-Former/data/218basins_list.txt", header=None, dtype=str)[0].values.tolist()
            df_static_selected = self.df_static.loc[glob_bas_list]
            self.df_static = self._standardize_static_data(df_static_selected)

            # Further restrict to the specific basins provided in basins_list
            if self.basins:
                self.df_static = self.df_static.loc[self.basins]

        # If final_data_path is not None, standardize using only the provided basins_list
        elif self.basins:
            # Handle the case when a single basin is provided as a string
            if isinstance(self.basins, str):
                self.basins = [self.basins]
            df_static_selected = self.df_static.loc[self.basins]
            self.df_static = self._standardize_static_data(df_static_selected)

    def get_df_static(self, basin):
        return self.df_static.loc[[basin]].values

    def _standardize_static_data(self, df_static):
        mean = df_static.mean()
        std = df_static.std()
        return (df_static - mean) / std


class CamelsDatasetWithStatic(CamelsDataset):
    """CAMELS dataset with static attributes injected into serialized sequences.

    Inherited from NullableCamelsDataset

    """

    def __init__(self, camels_root: str, forcing_type: str, basins_list: list, past_len: int, pred_len: int, stage: str,
                 dates: list, x_mean=None, y_mean=None, x_std=None, y_std=None, y_stds_dict=None):
        self.static_reader = StaticReader(camels_root, basins_list)
        self.norm_static_fea = dict()
        super().__init__(camels_root, forcing_type, basins_list, past_len, pred_len, stage,
                         dates, x_mean, y_mean, x_std, y_std, y_stds_dict)

    def _load_data(self, forcing_type):
        # Loading vanilla data
        basin_number = len(self.basins_list)

        for idx, basin in enumerate(self.basins_list):
            print(self.stage, f"{basin}: loading data %.4f" % (idx / basin_number))
            reader = HydroReaderFactory.get_hydro_reader(self.camels_root, forcing_type, basin)
            df_x = reader.get_df_x()
            df_y = reader.get_df_y()

            # Select date
            df_x = df_x[self.dates[0]:self.dates[1]]
            df_y = df_y[self.dates[0]:self.dates[1]]
            assert len(df_x) == len(df_y)
            self.date_index_dict[basin] = df_x.index

            #if self.stage == 'val' or self.stage == 'test':
            #    print("I have df_x and df_y")

            # Select used features and discharge
            x = df_x.values.astype("float32")
            y = df_y.values.astype("float32")

            #if self.stage == 'val' or self.stage == 'test':
            #    print("I have x and y")

            self.x_dict[basin] = x
            self.y_dict[basin] = y

            #if self.stage == 'val' or self.stage == 'test':
            #    print("I have x_dict and y_dict")

            self.length_ls.append(len(x) - self.past_len - self.pred_len + 1)
            # adding static attributes
            self.norm_static_fea[basin] = self.static_reader.get_df_static(basin)

            #if self.stage == 'val' or self.stage == 'test':
            #    print("I have norm_static_fea")

            #if self.stage == 'val' or self.stage == 'test':
            #    print("I have df_x and df_y")

            # Calculate mean and std in training stage
            if self.stage == 'train':
                self.y_stds_dict[basin] = y.std(axis=0).item()

    def normalize_data(self):
        #if self.stage == 'val' or self.stage == 'test':
        #    print("I am normalizing data for validation or test stage")
        # Normalize data
        for idx, basin in enumerate(self.basins_list):
            print(self.stage, "Normalizing %.4f" % (idx / len(self.basins_list)))
            x = self.x_dict[basin]
            y = self.y_dict[basin]
            # Normalize data
            x_norm = self._local_normalization(x, variable='inputs')
            y_norm = self._local_normalization(y, variable='output')
            norm_static_fea = self.norm_static_fea[basin].repeat(x_norm.shape[0], axis=0)
            x_norm_static = np.concatenate([x_norm, norm_static_fea], axis=1)
            self.x_dict[basin] = x_norm_static
            self.y_dict[basin] = y_norm

    def __getitem__(self, idx: int):

        # Debugging statements
        #print(f"Fetching item with idx: {idx}")
        #if self.stage == 'val' or self.stage == 'test':
        #    print("I am getting items for validation or test stage")
        #    print(f"Basins: {self.basins_list}")
        #    print(f"Fetching item with idx: {idx}")
        
        basin_idx = bisect_right(self.index_ls, idx) - 1
        local_idx = idx - self.index_ls[basin_idx]
        basin = self.basins_list[basin_idx]

        # More debugging statements
        #if self.stage == 'val' or self.stage == 'test':
        #    print(f"basin_idx: {basin_idx}, local_idx: {local_idx}, basin: {basin}")

        x_seq = self.x_dict[basin][local_idx: local_idx + self.past_len + self.pred_len, :]
        y_seq_past = self.y_dict[basin][local_idx: local_idx + self.past_len, :]
        y_seq_future = self.y_dict[basin][local_idx + self.past_len: local_idx + self.past_len + self.pred_len, :]

        return x_seq, y_seq_past, y_seq_future, self.y_stds_dict[basin]



class CamelsDatasetLimited(CamelsDataset):
    def __getitem__(self, idx: int):
        basin_idx = bisect_right(self.index_ls, idx) - 1
        local_idx = idx - self.index_ls[basin_idx]
        basin = self.basins_list[basin_idx]
        x_seq = self.x_dict[basin][local_idx: local_idx + self.past_len, :]
        y_seq_past = self.y_dict[basin][local_idx: local_idx + self.past_len, :]
        y_seq_future = self.y_dict[basin][local_idx + self.past_len: local_idx + self.past_len + self.pred_len, :]

        return x_seq, y_seq_past, y_seq_future, self.y_stds_dict[basin]


class DatasetFactory:
    @staticmethod
    def get_dataset_type(use_future_fea, use_static):
        if (not use_future_fea) and use_static:
            raise RuntimeError("No implemented yet.")
        elif not use_future_fea:
            ds = CamelsDatasetLimited
        elif use_static:
            #print("Initializing CamelsDatasetWithStatic")
            ds = CamelsDatasetWithStatic
            #print("Dataset initialized: CamelsDatasetWithStatic")
        else:
            ds = CamelsDataset
        return ds
