import time

from utils.eval_model import eval_model_obs_preds
#from utils.metrics import calc_nse, calc_mse
from utils.metrics import calc_mse, calc_rmse, calc_bias
from utils.metrics import calc_nse, calc_kge, calc_kgenp, calc_tpe, calc_fdc
from utils.tools import count_parameters, saving_obs_pred


def test_full(test_model, decode_mode, test_loader, device, saving_root, only_metrics: bool, date_index=None):
    """
    date_index will be used if only_metric == False
    """
    t1 = time.time()
    print(f"Parameters count:{count_parameters(test_model)}")
    log_file = saving_root / f"log_test.csv"
    obs, pred = eval_model_obs_preds(test_model, test_loader, decode_mode, device)

    obs = obs.numpy()
    pred = pred.numpy()
    _, mses_test = calc_mse(obs, pred)
    test_mse_mean = mses_test.mean()

    # Calculate nse after rescale (But if you take the same mean and std, it's equivalent before and after)
    obs_rescaled = test_loader.dataset.local_rescale(obs, variable='output')
    pred_rescaled = test_loader.dataset.local_rescale(pred, variable='output')
    _, nses_test = calc_nse(obs_rescaled, pred_rescaled)
    test_nse_mean = nses_test.mean()

    print(f"Testing mean mse: {test_mse_mean}, mean nse:{test_nse_mean}")

    with open(log_file, "wt") as f:
        f.write(f"parameters_count:{count_parameters(test_model)}\n")
        f.write(f"test_mse_mean:{test_mse_mean}\n")
        f.write(f"{','.join(f'mse{i + 1}' for i in range(len(mses_test)))}\n")
        f.write(f"{','.join(str(i) for i in list(mses_test))}\n")
        f.write(f"test_nse_mean:{test_nse_mean}\n")
        f.write(f"{','.join(f'nse{i + 1}' for i in range(len(nses_test)))}\n")
        f.write(f"{','.join(str(i) for i in list(nses_test))}\n")

    if not only_metrics:
        obs_pred_root = saving_root / "obs_pred"
        start_date = test_loader.dataset.dates[0]
        end_date = test_loader.dataset.dates[1]
        past_len = test_loader.dataset.past_len
        pred_len = test_loader.dataset.pred_len
        saving_obs_pred(obs_rescaled, pred_rescaled, start_date, end_date, past_len, pred_len, obs_pred_root,
                        date_index=date_index)

    t2 = time.time()
    print(f"Testing used time:{t2 - t1}")

#We add and extended version of the test_full function
def test_full_ext(test_model, decode_mode, test_loader, device, saving_root, only_metrics: bool, date_index=None):
    """
    date_index will be used if only_metric == False
    """
    t1 = time.time()
    print(f"Parameters count:{count_parameters(test_model)}")
    log_file = saving_root / f"log_test.csv"
    obs, pred = eval_model_obs_preds(test_model, test_loader, decode_mode, device)

    obs = obs.numpy()
    pred = pred.numpy()

    #MSE
    _, mses_test = calc_mse(obs, pred)
    test_mse_mean = mses_test.mean()
    #RMSE
    #_, rmses_test = calc_rmse(obs, pred)
    #test_rmse_mean = rmses_test.mean()
    #BIAS
    #_, biass_test = calc_bias(obs, pred)
    #test_bias_mean = biass_test.mean()

    # Calculate metrics after rescale (But if you take the same mean and std, it's equivalent before and after)
    obs_rescaled = test_loader.dataset.local_rescale(obs, variable='output')
    pred_rescaled = test_loader.dataset.local_rescale(pred, variable='output')
    #NSE
    _, nses_test = calc_nse(obs_rescaled, pred_rescaled)
    test_nse_mean = nses_test.mean()
    #KGE
    _, kges_test = calc_kge(obs_rescaled, pred_rescaled)
    test_kge_mean = kges_test.mean()
    #KGENP
    _, kgenps_test = calc_kgenp(obs_rescaled, pred_rescaled)
    test_kgenp_mean = kgenps_test.mean()

    #RMSE
    _, rmses_test = calc_rmse(obs_rescaled, pred_rescaled)
    test_rmse_mean = rmses_test.mean()
    #BIAS
    _, biass_test = calc_bias(obs_rescaled, pred_rescaled)
    test_bias_mean = biass_test.mean()

    #ATPE
    _, atpes_test = calc_tpe(obs_rescaled, pred_rescaled,alpha=0.2)
    test_atpe_mean = atpes_test.mean()

    #BIASFMS
    _, biasfms_test = calc_fdc(obs_rescaled, pred_rescaled)
    test_biasfms_mean = biasfms_test.mean()

    print(f"Testing mean MSE: {test_mse_mean}, mean NSE:{test_nse_mean}")
    print(f"Testing mean RMSE:{test_rmse_mean}, mean BIAS:{test_bias_mean}")
    print(f"Testing mean KGE:{test_kge_mean}, mean ATPE:{test_atpe_mean}")


    with open(log_file, "wt") as f:
        f.write(f"parameters_count:{count_parameters(test_model)}\n")
        f.write(f"test_mse_mean:{test_mse_mean}\n")
        f.write(f"{','.join(f'mse{i + 1}' for i in range(len(mses_test)))}\n")
        f.write(f"{','.join(str(i) for i in list(mses_test))}\n")
        f.write(f"test_rmse_mean:{test_rmse_mean}\n")
        f.write(f"{','.join(f'rmse{i + 1}' for i in range(len(rmses_test)))}\n")
        f.write(f"{','.join(str(i) for i in list(rmses_test))}\n")
        f.write(f"test_bias_mean:{test_bias_mean}\n")
        f.write(f"{','.join(f'bias{i + 1}' for i in range(len(biass_test)))}\n")
        f.write(f"{','.join(str(i) for i in list(biass_test))}\n")
        f.write(f"test_nse_mean:{test_nse_mean}\n")
        f.write(f"{','.join(f'nse{i + 1}' for i in range(len(nses_test)))}\n")
        f.write(f"{','.join(str(i) for i in list(nses_test))}\n")
        f.write(f"test_kge_mean:{test_kge_mean}\n")
        f.write(f"{','.join(f'kge{i + 1}' for i in range(len(kges_test)))}\n")
        f.write(f"{','.join(str(i) for i in list(kges_test))}\n")
        f.write(f"test_kgenp_mean:{test_kgenp_mean}\n")
        f.write(f"{','.join(f'kgenp{i + 1}' for i in range(len(kgenps_test)))}\n")
        f.write(f"{','.join(str(i) for i in list(kgenps_test))}\n")
        f.write(f"test_atpe_mean:{test_atpe_mean}\n")
        f.write(f"{','.join(f'atpe{i + 1}' for i in range(len(atpes_test)))}\n")
        f.write(f"{','.join(str(i) for i in list(atpes_test))}\n")
        f.write(f"test_biasfms_mean:{test_biasfms_mean}\n")
        f.write(f"{','.join(f'biasfms{i + 1}' for i in range(len(biasfms_test)))}\n")
        f.write((f"{','.join(str(i[0]) for i in list(biasfms_test))}\n"))

    if not only_metrics:
        obs_pred_root = saving_root / "obs_pred"
        start_date = test_loader.dataset.dates[0]
        end_date = test_loader.dataset.dates[1]
        past_len = test_loader.dataset.past_len
        pred_len = test_loader.dataset.pred_len
        saving_obs_pred(obs_rescaled, pred_rescaled, start_date, end_date, past_len, pred_len, obs_pred_root,
                        date_index=date_index)

    t2 = time.time()
    print(f"Testing used time:{t2 - t1}")
