import torch
import time
import os
from utils.train_epoch import train_epoch
from utils.eval_model import eval_model
from utils.tools import BoardWriter, count_parameters


class BestModelLog:
    def __init__(self, init_model, saving_root, metric_name, high_better: bool):
        self.high_better = high_better
        self.saving_root = saving_root
        self.metric_name = metric_name
        worst = float("-inf") if high_better else float("inf")
        self.best_epoch = -1
        self.best_value = worst
        self.best_model_path = self.saving_root / f"({self.metric_name})_{self.best_epoch}_{self.best_value}.pkl"
        torch.save(init_model.state_dict(), self.best_model_path)

    def update(self, model, new_value, epoch):
        if ((self.high_better is True) and (new_value > self.best_value)) or \
                ((self.high_better is False) and (new_value < self.best_value)):
            os.remove(self.best_model_path)
            self.best_value = new_value
            self.best_epoch = epoch
            self.best_model_path = self.saving_root / f"({self.metric_name})_{self.best_epoch}_{self.best_value}.pkl"
            torch.save(model.state_dict(), self.best_model_path)

# We add a class for EarlyStopping
# => to stop the training process when the validation loss does not decrease anymore
# It can quite reduce the training time (I guess?)
class EarlyStopping:
    def __init__(self, patience=10, verbose=False):
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = float('inf')

    #def __call__(self, metric, model, epoch, saving_root):
    #    score = -metric
    def __call__(self, val_loss):
        score = -val_loss

        if self.best_score is None:
            self.best_score = score
            #if epoch != 0:  # Avoid saving the model at epoch 0
                #self.save_checkpoint(metric, model, epoch, saving_root)
            self.val_loss_min = val_loss
        elif score < self.best_score:
            self.counter += 1
            if self.verbose:
                print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            #self.save_checkpoint(metric, model, epoch, saving_root)
            self.val_loss_min = val_loss
            self.counter = 0

    #def save_checkpoint(self, val_loss, model, epoch, saving_root):
    #    '''Saves model when validation loss decrease.'''
    #    if self.verbose:
    #        print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f}).')
    #    self.val_loss_min = val_loss
    #    # Save the model only every 10 epochs
    #    if epoch % 10 == 0:
    #        model_save_path = saving_root / f'best_model_epoch_{epoch}_metric_{val_loss}.pkl'
    #    # Shorten the file name
    #    model_save_path = saving_root / f'best_model_e{epoch}_m{val_loss:.4f}.pkl'
    #    torch.save(model.state_dict(), model_save_path)


def train_full(model, decode_mode, train_loader, val_loader, optimizer, scheduler, loss_func, n_epochs, device,
               saving_root, using_board=False):
    print(f"Parameters count:{count_parameters(model)}")
    log_file = saving_root / "log_train.csv"
    with open(log_file, "wt") as f:
        f.write(f"parameters_count:{count_parameters(model)}\n")
        f.write("epoch,train_loss_iterated,train_mse,val_mse,train_nse,val_nse\n")
    if using_board:
        tb_root = saving_root / "tb_log"
        writer = BoardWriter(tb_root)
    else:
        writer = None

    mse_log = BestModelLog(model, saving_root, "min_mse", high_better=False)
    nse_log = BestModelLog(model, saving_root, "max_nse", high_better=True)
    newest_log = BestModelLog(model, saving_root, "newest", high_better=True)

    # Initialize the early_stopping object
    early_stopping = EarlyStopping(patience=25, verbose=True)

    t1 = time.time()
    for i in range(n_epochs):
        print(f"Training progress: {i} / {n_epochs}")
        train_loss_iterated = train_epoch(model, train_loader, optimizer, scheduler, loss_func, decode_mode, device)
        # Debug: After calling train_epoch
        #print("Debug: After calling train_epoch")
        #print(f"train_loss_iterated: {train_loss_iterated}")
        mse_train, nse_train = '', ''
        # if mse_train, nse_train is not needed to be calculated (via eval_model function),
        # and you can comment the next line to speed up
        #print("I got to the eval_model function: training stage")
        mse_train, nse_train = eval_model(model, train_loader, decode_mode, device)
        # Debug: After calling eval_model for training stage
        #print("Debug: After calling eval_model (training stage)")
        #print(f"mse_train: {mse_train}, nse_train: {nse_train}")
        #print("I got to the eval_model function: validation stage")
        mse_val, nse_val = eval_model(model, val_loader, decode_mode, device)
        #print("I never finished running eval_model function at validation stage")  
    
        if writer is not None:
            if (mse_train != '') and (nse_train != ''):
                writer.write_board(f"train_mse", metric_value=mse_train, epoch=i)
                writer.write_board(f"train_nse", metric_value=nse_train, epoch=i)
            writer.write_board(f"train_loss(iterated)", metric_value=train_loss_iterated, epoch=i)
            writer.write_board("val_mse", metric_value=mse_val, epoch=i)
            writer.write_board("val_nse", metric_value=nse_val, epoch=i)
        with open(log_file, "at") as f:
            f.write(f"{i},{train_loss_iterated},{mse_train},{mse_val},{nse_train},{nse_val}\n")
        mse_log.update(model, mse_val, i)
        nse_log.update(model, nse_val, i)
        newest_log.update(model, i, i)

        early_stopping(mse_val)

        if early_stopping.early_stop:
            print(f"Early stopping at epoch {i}")
            break

    t2 = time.time()
    print(f"Training used time:{t2 - t1}")

    # Ensure mse_val is a float
    mse_val = float(mse_val)
    print(f"Validation MSE: {mse_val}")

    # Return the final validation loss
    return mse_val # We add this for Optuna to optimize the validation loss
