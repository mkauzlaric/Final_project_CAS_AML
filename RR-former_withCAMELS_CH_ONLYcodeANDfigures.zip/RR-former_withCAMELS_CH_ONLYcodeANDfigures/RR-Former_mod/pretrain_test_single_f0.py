import torch
import numpy as np
import json
import importlib
import os

from torch.utils.data import DataLoader

from configs.project_config import ProjectConfig
from configs.data_shape_config import DataShapeConfig
from configs.run_config.pretrain_config import PretrainConfig
from configs.run_config.fine_tune_config_f0 import FineTuneConfig
from utils.tools import SeedMethods
#from utils.test_full import test_full
from utils.test_full import test_full_ext #We add and extended version of the test_full function
from data.dataset import DatasetFactory

device = ProjectConfig.device
num_workers = ProjectConfig.num_workers

past_len = DataShapeConfig.past_len
pred_len = DataShapeConfig.pred_len
src_len = DataShapeConfig.src_len
tgt_len = DataShapeConfig.tgt_len
src_size = DataShapeConfig.src_size
tgt_size = DataShapeConfig.tgt_size
use_future_fea = DataShapeConfig.use_future_fea
use_static = DataShapeConfig.use_static

seed = PretrainConfig.seed
saving_message = PretrainConfig.saving_message
#saving_root = PretrainConfig.saving_root
used_model = PretrainConfig.used_model
decode_mode = PretrainConfig.decode_mode
pre_test_config = PretrainConfig.pre_test_config
batch_size = PretrainConfig.batch_size

saving_root = FineTuneConfig.pre_saving_root
exps_config = FineTuneConfig.exps_config

if __name__ == '__main__':
    print("pid:", os.getpid())
    SeedMethods.seed_torch(seed=seed)
    print(saving_root)
    # Model
    # # Define model type
    models = importlib.import_module("models")
    Model = getattr(models, used_model)
    best_path = list(saving_root.glob(f"(max_nse)*.pkl"))
    assert (len(best_path) == 1)
    best_path = best_path[0]
    best_model = Model().to(device)
    best_model.load_state_dict(torch.load(best_path, map_location=device))

    # Dataset
    DS = DatasetFactory.get_dataset_type(use_future_fea, use_static)
    # # Needs training mean and training std
    train_means = np.loadtxt(saving_root / "train_means.csv", dtype="float32")
    train_stds = np.loadtxt(saving_root / "train_stds.csv", dtype="float32")
    train_x_mean = train_means[:-1]
    train_y_mean = train_means[-1]
    train_x_std = train_stds[:-1]
    train_y_std = train_stds[-1]
    #with open(saving_root / "y_stds_dict.json", "rt") as f: # TODO when running pretrain_test on a globally trained model
    with open(saving_root / "global_y_stds_dict.json", "rt") as f: # TODO when running pretrain_test after kfold splitting, use test_basins_list
        y_stds_dict = json.load(f)

    exps_num = len(exps_config)
    for idx, exp_config in enumerate(exps_config):
        print(f"==========Now process: {idx} / {exps_num}===========")
        SeedMethods.seed_torch(seed=seed)
        #root_now = saving_root / "pretrain_test_single" / exp_config["tag"]
        root_now = saving_root / "pretrain_test_single_ext" / exp_config["tag"] #We add and extended test folder (with additional metrics)
        root_now.mkdir(parents=True, exist_ok=True)
        # Testing data (needs training mean and training std)
        ds_test = DS.get_instance(past_len, pred_len, "test", specific_cfg=exp_config["ft_test_config"],
                                  x_mean=train_x_mean, y_mean=train_y_mean, x_std=train_x_std, y_std=train_y_std,
                                  y_stds_dict=y_stds_dict)
        test_loader = DataLoader(ds_test, batch_size=batch_size, num_workers=num_workers, shuffle=False)
        date_index = test_loader.dataset.date_index_dict[exp_config["tag"]]

        #test_full(best_model, decode_mode, test_loader, device, root_now, False, date_index=date_index)
        test_full_ext(best_model, decode_mode, test_loader, device, root_now, True, date_index=date_index)
